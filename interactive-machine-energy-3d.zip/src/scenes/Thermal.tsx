import { Bx, Cy, Pipe, PolyPipe, Beam, Spin, Flow, Smoke, Ground, Trees, CoolingTower, Transformer, PowerLine, GlassHall, M, type Clock, type V3 } from "./common";
import { Line } from "@react-three/drei";

export default function Thermal({ clock }: { clock: Clock }) {
  const steam: V3[] = [[-5, 8, 0], [-3, 8, 0], [-3, 2.6, 0], [-0.9, 2.6, 0]];
  const feed: V3[] = [[-1.5, 0.6, 0.9], [-5, 0.6, 0.9]];
  const cool: V3[] = [[2.3, 0.6, 0], [6, 0.6, 0], [6, 0.6, -8], [9.8, 0.6, -8]];
  const elec: V3[] = [[5, 3.4, 0], [5, 5.6, 0], [8, 5.6, 4], [8, 2.3, 4]];

  return (
    <group>
      <Ground color="#79806b" />
      <Bx p={[0, 0.03, 0]} s={[70, 0.06, 40]} m={M.concreteDark} cast={false} />

      {/* Convoyeur à charbon + tas */}
      <Beam a={[-21, 0.9, 0]} b={[-11.2, 7.2, 0]} w={1} h={0.3} m={M.steelDark} />
      {[-19, -16, -13].map((x, i) => (
        <Beam key={i} a={[x, 0, 0.5]} b={[x, 0.9 + i * 2, 0.5]} w={0.15} h={0.15} />
      ))}
      <mesh position={[-21.5, 1.3, 0]} castShadow>
        <coneGeometry args={[3, 2.6, 12]} />
        <meshStandardMaterial color="#1b1b1d" roughness={1} flatShading />
      </mesh>

      {/* Chaudière */}
      <Bx p={[-8, 5, 0]} s={[6, 10, 6]} m={M.steel} />
      {Array.from({ length: 6 }).map((_, i) => (
        <Bx key={i} p={[-8, 1.2 + i * 1.6, 3.02]} s={[5.4, 0.9, 0.05]} m={M.steelDark} cast={false} />
      ))}
      <Bx p={[-8, 10.2, 0]} s={[6.4, 0.4, 6.4]} m={M.steelDark} />
      <Bx p={[-8, 8, -4.2]} s={[1.2, 1.2, 2.8]} m={M.steelDark} />
      {/* Cheminée */}
      {[0, 1, 2, 3, 4].map((i) => (
        <Cy key={i} p={[-8, 2 + i * 4, -6]} rt={1.1 - (i + 0.5) * 0.06} rb={1.1 - (i - 0.5) * 0.06} h={4} m={i % 2 ? M.white : M.red} />
      ))}
      <Smoke position={[-8, 22.3, -6]} clock={clock} count={34} rise={11} size={0.7} grow={3.2} color="#9a9a9a" opacity={0.4} speed={0.06} spread={0.5} drift={[2.5, 0, 0.8]} />

      {/* Tuyauterie vapeur */}
      <PolyPipe pts={steam} r={0.22} m={M.orange} />
      <Flow points={steam} count={22} speed={0.12} size={0.13} color="#ffe9c0" clock={clock} />
      <Pipe a={feed[0]} b={feed[1]} r={0.2} m={M.blue} />
      <Flow points={feed} count={8} speed={0.1} size={0.1} color="#6fc8ff" clock={clock} reverse />

      {/* Salle des machines */}
      <GlassHall p={[2, 2.5, 0]} s={[10, 5, 6]} />
      <Bx p={[2, 0.05, 0]} s={[10.4, 0.1, 6.4]} m={M.concreteDark} />
      {/* Turbine à vapeur (axe X) */}
      <Cy p={[0.5, 2.6, 0]} rt={0.95} h={3} rot={[0, 0, Math.PI / 2]} m={M.glassDense} cast={false} />
      <Spin clock={clock} speed={6} axis="x" position={[0.5, 2.6, 0]}>
        <Cy rt={0.12} h={3.4} rot={[0, 0, Math.PI / 2]} m={M.chrome} />
        {[-1.2, -0.8, -0.4, 0, 0.4, 0.8, 1.2].map((x, i) => (
          <group key={i} position={[x, 0, 0]}>
            <Cy rt={0.3 + i * 0.07} h={0.06} rot={[0, 0, Math.PI / 2]} m={M.steelDark} />
            {Array.from({ length: 10 }).map((_, k) => {
              const a = (k / 10) * Math.PI * 2;
              const rr = 0.3 + i * 0.07;
              return <Bx key={k} p={[0, Math.cos(a) * rr, Math.sin(a) * rr]} s={[0.05, 0.12, 0.1]} rot={[a, 0, 0]} m={M.chrome} />;
            })}
          </group>
        ))}
      </Spin>
      {/* Alternateur */}
      <Cy p={[4.6, 2.6, 0]} rt={1.05} h={3.0} rot={[0, 0, Math.PI / 2]} m={M.blue} />
      <Cy p={[6.15, 2.6, 0]} rt={0.7} h={0.1} rot={[0, 0, Math.PI / 2]} m={M.steelDark} />
      <Spin clock={clock} speed={6} axis="x" position={[2.5, 2.6, 0]}>
        <Cy rt={0.16} h={1.2} rot={[0, 0, Math.PI / 2]} m={M.chrome} />
        <Bx p={[0, 0.17, 0]} s={[1.1, 0.04, 0.06]} m={M.red} />
      </Spin>
      {/* Condenseur */}
      <Bx p={[0.5, 0.9, 0]} s={[3.6, 1.4, 2.4]} m={M.steel} />
      {[-1.2, -0.4, 0.4, 1.2].map((x) => (
        <Bx key={x} p={[0.5 + x, 0.9, 1.22]} s={[0.1, 1.2, 0.05]} m={M.steelDark} cast={false} />
      ))}
      {/* Pieds */}
      <Bx p={[0.5, 1.8, 0]} s={[3.4, 0.2, 2.2]} m={M.steelDark} />

      {/* Circuit de refroidissement + tour */}
      <PolyPipe pts={cool} r={0.3} m={M.steel} />
      <Flow points={cool} count={22} speed={0.07} size={0.12} color="#4cc3ff" clock={clock} />
      <CoolingTower position={[14, 0, -8]} r={4} h={14} />
      <Smoke position={[14, 14, -8]} clock={clock} count={30} rise={9} size={1.1} grow={2.8} opacity={0.4} speed={0.05} spread={1.5} drift={[3, 0, 1]} />

      {/* Électricité */}
      <Line points={elec} color="#2a2a2a" lineWidth={1.5} />
      <Flow points={elec} count={14} speed={0.12} size={0.1} color="#ffd24a" clock={clock} />
      <Transformer position={[8, 0, 4]} />
      <PowerLine start={[8, 2.3, 4]} x1={15} x2={35} z={8} clock={clock} />

      <Trees list={[[-16, 10], [-12, 14], [-6, 13], [4, 14], [12, 16], [20, 8], [26, -4], [-24, -12], [-18, -14], [24, 14], [-28, 8]]} />
    </group>
  );
}
