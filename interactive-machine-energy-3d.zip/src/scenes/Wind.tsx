import { useMemo } from "react";
import * as THREE from "three";
import { Bx, Cy, Pipe, Spin, Flow, Transformer, PowerLine, M, type Clock, type V3 } from "./common";
import { Line, Edges } from "@react-three/drei";

const terrainH = (x: number, z: number) => {
  const d = Math.hypot(x, z);
  const k = THREE.MathUtils.smoothstep(d, 38, 85);
  return k * (Math.sin(x * 0.045) * Math.cos(z * 0.04) * 5 + Math.sin(x * 0.11 + z * 0.07) * 1.4 + 6);
};

function Terrain() {
  const geo = useMemo(() => {
    const g = new THREE.PlaneGeometry(400, 400, 120, 120);
    const pos = g.attributes.position;
    const col: number[] = [];
    const c1 = new THREE.Color("#6f8c4a");
    const c2 = new THREE.Color("#8a9a58");
    const c = new THREE.Color();
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = -pos.getY(i);
      const h = terrainH(x, z);
      pos.setZ(i, h);
      c.copy(c1).lerp(c2, THREE.MathUtils.clamp(h / 10 + Math.sin(x * 0.2) * 0.1, 0, 1));
      col.push(c.r, c.g, c.b);
    }
    g.setAttribute("color", new THREE.Float32BufferAttribute(col, 3));
    g.computeVertexNormals();
    return g;
  }, []);
  return (
    <mesh geometry={geo} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
      <meshStandardMaterial vertexColors roughness={1} />
    </mesh>
  );
}

function bladeGeometry() {
  const s = new THREE.Shape();
  s.moveTo(-0.1, 0.3);
  s.lineTo(0.0, 0.3);
  s.bezierCurveTo(0.34, 0.9, 0.34, 1.6, 0.26, 3);
  s.bezierCurveTo(0.2, 5, 0.1, 6.5, 0.02, 7.2);
  s.lineTo(-0.05, 7.2);
  s.bezierCurveTo(-0.1, 5, -0.12, 2, -0.1, 0.3);
  const g = new THREE.ExtrudeGeometry(s, { depth: 0.1, bevelEnabled: true, bevelSize: 0.03, bevelThickness: 0.03, bevelSegments: 2, curveSegments: 18 });
  return g;
}

function Turbine({ position, scale = 1, clock, detail = false, phase = 0, rotY = 0 }: { position: V3; scale?: number; clock: Clock; detail?: boolean; phase?: number; rotY?: number }) {
  const blade = useMemo(bladeGeometry, []);
  return (
    <group position={position} scale={scale} rotation={[0, rotY, 0]}>
      {/* Mât */}
      <mesh position={[0, 7, 0]} castShadow receiveShadow>
        <cylinderGeometry args={[0.2, 0.34, 14, 32]} />
        <meshStandardMaterial color="#f1f3f3" roughness={0.4} metalness={0.15} />
      </mesh>
      <Cy p={[0, 0.25, 0]} rt={0.5} h={0.5} m={M.concreteDark} />
      {/* Tête (axe local z -> monde x) */}
      <group position={[0, 14.35, 0]} rotation={[0, Math.PI / 2, 0]}>
        {/* Nacelle */}
        {detail ? (
          <>
            <mesh position={[0, 0, -0.2]} material={M.glassDense}>
              <boxGeometry args={[0.9, 0.9, 3.4]} />
              <Edges color="#ffffff" threshold={15} />
            </mesh>
            <Cy p={[0, 0, 1.0]} rt={0.12} h={1.2} rot={[Math.PI / 2, 0, 0]} m={M.chrome} />
            <Bx p={[0, 0, 0.5]} s={[0.55, 0.5, 0.7]} m={M.steelDark} />
            <Cy p={[0, 0, -0.35]} rt={0.05} h={0.9} rot={[Math.PI / 2, 0, 0]} m={M.chrome} />
            <Cy p={[0, 0, -1.0]} rt={0.3} h={0.9} rot={[Math.PI / 2, 0, 0]} m={M.red} />
            <Spin clock={clock} speed={9} axis="z" position={[0, 0, -0.35]}>
              <Bx p={[0.05, 0, 0]} s={[0.1, 0.03, 0.03]} m={M.red} />
            </Spin>
            <Bx p={[0, 0.5, -1.3]} s={[0.1, 0.1, 0.1]} m={M.yellow} />
          </>
        ) : (
          <>
            <Bx p={[0, 0, -0.2]} s={[0.9, 0.9, 3.4]} m={M.white} />
          </>
        )}
        {/* Rotor */}
        <Spin clock={clock} speed={1.1} axis="z" position={[0, 0, 1.75]} rotation={[0, 0, phase]}>
          <mesh rotation={[Math.PI / 2, 0, 0]} position={[0, 0, 0.1]} castShadow>
            <sphereGeometry args={[0.5, 32, 24]} />
            <meshStandardMaterial color="#f4f6f6" roughness={0.3} metalness={0.2} />
          </mesh>
          <mesh position={[0, 0, 0.55]} rotation={[Math.PI / 2, 0, 0]} castShadow>
            <coneGeometry args={[0.38, 0.7, 32]} />
            <meshStandardMaterial color="#f4f6f6" roughness={0.3} metalness={0.2} />
          </mesh>
          {[0, 1, 2].map((i) => (
            <group key={i} rotation={[0, 0, (i * Math.PI * 2) / 3]}>
              <mesh geometry={blade} rotation={[0, 0.32, 0]} position={[0, 0.3, -0.05]} castShadow receiveShadow>
                <meshStandardMaterial color="#f6f7f7" roughness={0.32} metalness={0.1} side={THREE.DoubleSide} />
              </mesh>
            </group>
          ))}
        </Spin>
      </group>
    </group>
  );
}

export default function Wind({ clock }: { clock: Clock }) {
  const cable: V3[] = [[0, 0.5, 0.4], [3, 0.3, 2.5], [6, 0.3, 5.5]];
  const streams = useMemo(() => {
    const out: V3[][] = [];
    for (let i = 0; i < 14; i++) {
      const a = (i / 14) * Math.PI * 2 + 0.3;
      const rr = 3 + (i % 4) * 2.1;
      const y = 14.4 + Math.sin(a) * rr;
      const z = Math.cos(a) * rr;
      out.push([[26, y, z], [12, y + (i % 3) * 0.2, z * 0.96], [2.3, y, z], [-14, y - 0.4, z * 1.1], [-26, y - 0.6, z * 1.2]]);
    }
    return out;
  }, []);

  return (
    <group>
      <Terrain />
      <Turbine position={[0, 0, 0]} clock={clock} detail />
      <Turbine position={[-18, terrainH(-18, -26), -26]} scale={0.85} clock={clock} phase={0.8} />
      <Turbine position={[16, terrainH(16, -32), -32]} scale={0.8} clock={clock} phase={2.0} />
      <Turbine position={[-44, terrainH(-44, -40), -40]} scale={0.8} clock={clock} phase={1.4} />
      <Turbine position={[40, terrainH(40, -20), -20]} scale={0.85} clock={clock} phase={0.3} />
      <Turbine position={[-34, terrainH(-34, 18), 18]} scale={0.85} clock={clock} phase={1.9} />
      <Turbine position={[52, terrainH(52, -48), -48]} scale={0.7} clock={clock} phase={2.7} />
      <Turbine position={[-8, terrainH(-8, -52), -52]} scale={0.7} clock={clock} phase={0.5} />

      {/* Lignes de vent */}
      {streams.map((s, i) => (
        <group key={i}>
          <Line points={s} color="#ffffff" transparent opacity={0.16} lineWidth={1} />
          <Flow points={s} count={7} speed={0.06 + (i % 3) * 0.008} size={0.1} color="#ffffff" clock={clock} />
        </group>
      ))}

      {/* Électricité */}
      <Bx p={[1.5, 0.05, 1.5]} s={[1.6, 0.1, 1.6]} m={M.concreteDark} cast={false} />
      <Pipe a={[0.3, 0.4, 0.3]} b={[3, 0.3, 2.5]} r={0.05} m={M.black} />
      <Pipe a={[3, 0.3, 2.5]} b={[6, 0.3, 5.5]} r={0.05} m={M.black} />
      <Flow points={cable} count={8} speed={0.12} size={0.08} color="#ffd24a" clock={clock} />
      <Transformer position={[7, 0, 5.5]} />
      <PowerLine start={[7, 2.3, 5.5]} x1={15} x2={36} z={5.5} clock={clock} />
    </group>
  );
}
