import { useMemo } from "react";
import * as THREE from "three";
import { Bx, Cy, Pipe, PolyPipe, Spin, Flow, Water, Ground, Trees, Hill, Transformer, PowerLine, GlassHall, M, type Clock, type V3 } from "./common";
import { Line } from "@react-three/drei";

export default function Hydro({ clock }: { clock: Clock }) {
  const dam = useMemo(() => {
    const s = new THREE.Shape();
    s.moveTo(-3, 0);
    s.lineTo(-3, 4.6);
    s.lineTo(-1.8, 4.6);
    s.lineTo(2.2, 0);
    s.closePath();
    return new THREE.ExtrudeGeometry(s, { depth: 6.8, bevelEnabled: false });
  }, []);

  const penstock: V3[] = [[-3.4, 2.6, 0], [-2.6, 2.6, 0], [1.0, 0.75, 0], [5.5, 0.75, 0]];
  const cable: V3[] = [[7.3, 2.3, 0.4], [9.0, 2.6, 3.5], [10, 2.3, 3.5]];

  return (
    <group>
      <Ground color="#6f7f4f" />
      <Hill p={[-30, 0, -45]} r={34} h={26} color="#66745a" />
      <Hill p={[10, 0, -55]} r={40} h={22} color="#5c6a52" />
      <Hill p={[50, 0, -40]} r={30} h={18} color="#6b7a5a" />
      <Hill p={[-60, 0, 0]} r={26} h={16} color="#6b7a5a" />

      {/* Retenue */}
      <Bx p={[-10, 2, 0]} s={[13.8, 3.98, 15.8]} m={M.waterBody} cast={false} />
      <Water position={[-10, 4.03, 0]} size={[13.8, 15.8]} seg={[36, 40]} amp={0.045} clock={clock} />
      <Bx p={[-10, 2.5, -8.8]} s={[14, 5, 1.6]} m={M.rock} />
      <Bx p={[-10, 2.5, 8.8]} s={[14, 5, 1.6]} m={M.rock} />
      <Bx p={[-17.6, 3, 0]} s={[2.6, 6, 19]} m={M.rock} />
      <Hill p={[-24, 0, 10]} r={12} h={11} color="#757062" />
      <Hill p={[-24, 0, -10]} r={12} h={12} color="#757062" />

      {/* Barrage (coupe) */}
      <mesh geometry={dam} material={M.concrete} position={[0, 0, -8]} castShadow receiveShadow />
      <mesh geometry={dam} material={M.concrete} position={[0, 0, 1.2]} castShadow receiveShadow />
      <Bx p={[1, 0.25, 0]} s={[6.4, 0.5, 2.4]} m={M.concreteDark} />
      <Bx p={[-3.15, 2.3, 0]} s={[0.3, 4.6, 2.4]} m={M.concrete} />
      <Bx p={[-3.2, 2.6, 0]} s={[0.08, 1.2, 1.2]} m={M.steelDark} />
      {/* passerelle de crête */}
      <Bx p={[-2.4, 4.75, -4.6]} s={[1.2, 0.2, 6.8]} m={M.concreteDark} />
      <Bx p={[-2.4, 4.75, 4.6]} s={[1.2, 0.2, 6.8]} m={M.concreteDark} />

      {/* Conduite forcée */}
      <PolyPipe pts={penstock} r={0.4} m={M.steel} />
      <Flow points={penstock} count={18} speed={0.09} size={0.13} color="#7fd4ff" clock={clock} />

      {/* Centrale */}
      <Bx p={[6.4, 0.1, 0]} s={[4.8, 0.2, 5.4]} m={M.concreteDark} />
      <GlassHall p={[6.4, 1.8, 0]} s={[4.6, 3.4, 5.2]} />

      {/* Turbine Francis */}
      <group position={[6.4, 0, 0]}>
        <mesh position={[0, 0.75, 0]} rotation={[Math.PI / 2, 0, 0]} castShadow receiveShadow>
          <torusGeometry args={[0.95, 0.34, 28, 60]} />
          <meshStandardMaterial color="#2f7d4f" roughness={0.4} metalness={0.5} />
        </mesh>
        <Spin clock={clock} speed={4} axis="y" position={[0, 1.0, 0]}>
          <Cy rt={0.62} h={0.3} m={M.steelDark} />
          {Array.from({ length: 14 }).map((_, i) => {
            const a = (i / 14) * Math.PI * 2;
            return <Bx key={i} p={[Math.cos(a) * 0.62, 0, Math.sin(a) * 0.62]} s={[0.06, 0.28, 0.42]} rot={[0, -a + 0.5, 0]} m={M.chrome} />;
          })}
        </Spin>
        <Spin clock={clock} speed={4} axis="y" position={[0, 1.6, 0]}>
          <Cy rt={0.13} h={1.5} m={M.chrome} />
          <Bx p={[0.13, 0, 0]} s={[0.04, 1.4, 0.04]} m={M.red} />
        </Spin>
        {/* Alternateur */}
        <Cy p={[0, 2.3, 0]} rt={0.95} h={0.9} m={M.blue} />
        <Cy p={[0, 2.78, 0]} rt={0.98} h={0.06} m={M.steelDark} />
        <Spin clock={clock} speed={4} axis="y" position={[0, 2.88, 0]}>
          <Cy rt={0.78} h={0.1} m={M.steelDark} />
          {Array.from({ length: 12 }).map((_, i) => {
            const a = (i / 12) * Math.PI * 2;
            return <Bx key={i} p={[Math.cos(a) * 0.66, 0.1, Math.sin(a) * 0.66]} s={[0.22, 0.12, 0.14]} rot={[0, -a, 0]} m={M.copper} />;
          })}
          <Cy p={[0, 0.1, 0]} rt={0.12} h={0.14} m={M.chrome} />
        </Spin>
        {/* Tube d'aspiration */}
        <Pipe a={[0, 0.5, 0]} b={[2.4, 0.3, 0]} r={0.5} m={M.concreteDark} />
      </group>
      <Flow points={[[6.4, 0.4, 0], [8.7, 0.3, 0], [27, 0.35, 0]]} count={26} speed={0.07} size={0.12} color="#9fe0ff" clock={clock} />

      {/* Rivière aval */}
      <Water position={[19.5, 0.12, 0]} size={[22, 6]} seg={[40, 12]} amp={0.04} clock={clock} />
      <Bx p={[19.5, 0.06, 3.4]} s={[22, 0.3, 1]} m={M.rock} />
      <Bx p={[19.5, 0.06, -3.4]} s={[22, 0.3, 1]} m={M.rock} />

      {/* Électricité */}
      <Line points={cable} color="#2a2a2a" lineWidth={1.5} />
      <Flow points={cable} count={8} speed={0.15} size={0.09} color="#ffd24a" clock={clock} />
      <Transformer position={[10, 0, 3.5]} />
      <PowerLine start={[10, 2.3, 3.5]} x1={15} x2={35} z={3.5} clock={clock} />

      <Trees list={[[-6, 14], [-2, 16], [3, 13], [8, 15], [13, 12], [-12, 15], [18, -8], [22, -10], [14, -10], [26, -7], [-8, -16], [0, -14], [6, -12]]} />
    </group>
  );
}
