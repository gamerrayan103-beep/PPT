import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Bx, Cy, Sp, Pipe, PolyPipe, Spin, Flow, Smoke, Ground, Trees, CoolingTower, Transformer, PowerLine, GlassHall, M, type Clock, type V3 } from "./common";
import { Line } from "@react-three/drei";

function Core({ clock }: { clock: Clock }) {
  const mat = useRef<THREE.MeshStandardMaterial>(null);
  const rods = useRef<THREE.Group>(null);
  useFrame(() => {
    const t = clock.current;
    if (mat.current) mat.current.emissiveIntensity = 2.2 + Math.sin(t * 3) * 0.5;
    if (rods.current) rods.current.position.y = 0.35 + (Math.sin(t * 0.6) * 0.5 + 0.5) * 0.7;
  });
  const rodPos: [number, number][] = [[-0.35, -0.2], [0, 0.3], [0.35, -0.2], [0, -0.45], [0.4, 0.3], [-0.4, 0.3]];
  return (
    <group position={[-10.6, 0, 0]}>
      <Cy p={[0, 1.55, 0]} rt={0.72} h={1.5} seg={32} cast={false}>
        <meshStandardMaterial ref={mat} color="#0a2a3a" emissive="#35c8ff" emissiveIntensity={2.2} roughness={0.3} />
      </Cy>
      {/* assemblages */}
      {rodPos.map(([x, z], i) => (
        <Cy key={i} p={[x, 1.55, z]} rt={0.07} h={1.5} m={M.chrome} cast={false} />
      ))}
      {/* barres de contrôle */}
      <group ref={rods}>
        {rodPos.map(([x, z], i) => (
          <Cy key={i} p={[x * 0.9, 2.3, z * 0.9]} rt={0.045} h={1.8} m={M.black} cast={false} />
        ))}
      </group>
      <pointLight position={[0, 1.6, 0]} color="#35c8ff" intensity={6} distance={7} />
    </group>
  );
}

export default function Nuclear({ clock }: { clock: Clock }) {
  const hot: V3[] = [[-9.6, 3.0, 0], [-7.4, 3.0, 0]];
  const cold: V3[] = [[-7.4, 0.9, 0.3], [-8.4, 0.9, 1.5], [-10.6, 0.9, 1.5], [-10.6, 0.9, 0.9]];
  const steam: V3[] = [[-6.6, 4.4, 0], [-6.6, 4.9, 0], [1.8, 4.9, 0], [1.8, 2.4, 0], [2.5, 2.4, 0]];
  const feed: V3[] = [[2.2, 0.6, 1.0], [-5.5, 0.6, 1.0], [-5.5, 1.6, 0.9], [-6.0, 1.6, 0.5]];
  const cool1: V3[] = [[5.8, 0.6, 0], [12, 0.6, 0], [12, 0.6, -8], [13, 0.6, -8]];
  const cool2: V3[] = [[12, 0.6, 0], [12, 0.6, -18], [13, 0.6, -18]];
  const elec: V3[] = [[7.6, 3.6, 0], [7.6, 5.4, 0], [8, 5.4, 5.5], [8, 2.3, 5.5]];

  return (
    <group>
      <Ground color="#78856a" />
      <Bx p={[2, 0.03, -2]} s={[70, 0.06, 44]} m={M.concreteDark} cast={false} />

      {/* Enceinte de confinement (transparente) */}
      <group position={[-8.6, 0, 0]}>
        <Cy p={[0, 3, 0]} rt={4} h={6} m={M.glassDense} cast={false} />
        <Sp p={[0, 6, 0]} r={4} m={M.glassDense} theta={Math.PI / 2} cast={false} />
        <Cy p={[0, 0.15, 0]} rt={4.3} h={0.3} m={M.concreteDark} />
        {/* anneaux de béton visibles */}
        {[2, 4, 6].map((y) => (
          <mesh key={y} position={[0, y, 0]} rotation={[Math.PI / 2, 0, 0]}>
            <torusGeometry args={[y === 6 ? 4 : 4.01, 0.04, 6, 64]} />
            <meshStandardMaterial color="#dcdad3" />
          </mesh>
        ))}
      </group>

      {/* Cuve du réacteur */}
      <group position={[-10.6, 0, 0]}>
        <Cy p={[0, 2.0, 0]} rt={1.0} h={3.6} m={M.steel} cast={false}>
          <meshPhysicalMaterial color="#8d97a2" metalness={0.8} roughness={0.35} transparent opacity={0.3} depthWrite={false} />
        </Cy>
        <Sp p={[0, 3.8, 0]} r={1.0} theta={Math.PI / 2} cast={false} m={M.glassDense} />
        <Cy p={[0, 0.1, 0]} rt={1.1} h={0.3} m={M.steelDark} />
      </group>
      <Core clock={clock} />

      {/* Générateur de vapeur */}
      <Cy p={[-6.6, 2.1, 0]} rt={0.8} h={4.2} m={M.red} />
      <Sp p={[-6.6, 4.2, 0]} r={0.8} theta={Math.PI / 2} m={M.red} />
      <Cy p={[-6.6, 0.1, 0]} rt={0.95} h={0.2} m={M.steelDark} />
      {/* Pressuriseur */}
      <Cy p={[-8.5, 2, -2.4]} rt={0.45} h={4} m={M.steel} />
      <Sp p={[-8.5, 4, -2.4]} r={0.45} theta={Math.PI / 2} m={M.steel} />
      <Pipe a={[-8.5, 3, 0]} b={[-8.5, 3, -2.4]} r={0.12} m={M.steel} />

      {/* Circuit primaire */}
      <Pipe a={hot[0]} b={hot[1]} r={0.28} m={M.red} />
      <Flow points={hot} count={6} speed={0.15} size={0.12} color="#ff5a3c" clock={clock} />
      <PolyPipe pts={cold} r={0.28} m={M.blue} />
      <Flow points={cold} count={12} speed={0.12} size={0.12} color="#4cc3ff" clock={clock} />
      <Sp p={[-9.4, 0.9, 1.5]} r={0.45} m={M.steelDark} />
      <Spin clock={clock} speed={8} axis="y" position={[-9.4, 1.4, 1.5]}>
        <Cy rt={0.08} h={0.4} m={M.chrome} />
      </Spin>

      {/* Circuit secondaire */}
      <PolyPipe pts={steam} r={0.24} m={M.orange} />
      <Flow points={steam} count={26} speed={0.1} size={0.13} color="#ffe9c0" clock={clock} />
      <PolyPipe pts={feed} r={0.2} m={M.blue} />
      <Flow points={feed} count={14} speed={0.09} size={0.1} color="#6fc8ff" clock={clock} reverse />
      {[-4, 0].map((x) => (
        <Bx key={x} p={[x, 2.4, 0]} s={[0.25, 4.8, 0.25]} m={M.steelDark} />
      ))}

      {/* Salle des machines */}
      <GlassHall p={[6, 2.5, 0]} s={[10, 5, 6]} />
      <Bx p={[6, 0.05, 0]} s={[10.4, 0.1, 6.4]} m={M.concreteDark} />
      <Cy p={[4.1, 2.4, 0]} rt={0.95} h={3} rot={[0, 0, Math.PI / 2]} m={M.glassDense} cast={false} />
      <Spin clock={clock} speed={6} axis="x" position={[4.1, 2.4, 0]}>
        <Cy rt={0.12} h={3.4} rot={[0, 0, Math.PI / 2]} m={M.chrome} />
        {[-1.2, -0.8, -0.4, 0, 0.4, 0.8, 1.2].map((x, i) => (
          <group key={i} position={[x, 0, 0]}>
            <Cy rt={0.3 + i * 0.07} h={0.06} rot={[0, 0, Math.PI / 2]} m={M.steelDark} />
            {Array.from({ length: 10 }).map((_, k) => {
              const a = (k / 10) * Math.PI * 2;
              const rr = 0.3 + i * 0.07;
              return <Bx key={k} p={[0, Math.cos(a) * rr, Math.sin(a) * rr]} s={[0.05, 0.12, 0.1]} rot={[a, 0, 0]} m={M.chrome} />;
            })}
          </group>
        ))}
      </Spin>
      <Cy p={[7.6, 2.4, 0]} rt={1.05} h={3.2} rot={[0, 0, Math.PI / 2]} m={M.blue} />
      <Cy p={[9.25, 2.4, 0]} rt={0.7} h={0.1} rot={[0, 0, Math.PI / 2]} m={M.steelDark} />
      <Bx p={[4, 0.9, 0]} s={[3.6, 1.4, 2.4]} m={M.steel} />
      <Bx p={[4, 1.8, 0]} s={[3.4, 0.2, 2.2]} m={M.steelDark} />

      {/* Refroidissement */}
      <PolyPipe pts={cool1} r={0.32} m={M.steel} />
      <PolyPipe pts={cool2} r={0.32} m={M.steel} />
      <Flow points={cool1} count={22} speed={0.07} size={0.13} color="#4cc3ff" clock={clock} />
      <Flow points={cool2} count={14} speed={0.07} size={0.13} color="#4cc3ff" clock={clock} />
      <CoolingTower position={[17, 0, -8]} r={4.4} h={15} />
      <CoolingTower position={[17, 0, -18]} r={4.4} h={15} />
      <Smoke position={[17, 15, -8]} clock={clock} count={32} rise={10} size={1.2} grow={2.8} opacity={0.42} speed={0.05} spread={1.6} drift={[3, 0, 1]} />
      <Smoke position={[17, 15, -18]} clock={clock} count={32} rise={10} size={1.2} grow={2.8} opacity={0.42} speed={0.05} spread={1.6} drift={[3, 0, 1]} />

      {/* Électricité */}
      <Line points={elec} color="#2a2a2a" lineWidth={1.5} />
      <Flow points={elec} count={14} speed={0.12} size={0.1} color="#ffd24a" clock={clock} />
      <Transformer position={[8, 0, 5.5]} />
      <PowerLine start={[8, 2.3, 5.5]} x1={14} x2={34} z={10} clock={clock} />

      <Trees list={[[-20, 8], [-16, 12], [-10, 12], [-2, 12], [4, 14], [20, 10], [26, 4], [-22, -6], [-19, -13], [28, -14], [-6, -10]]} />
    </group>
  );
}
