import { useMemo } from "react";
import * as THREE from "three";
import { Bx, Cy, Pipe, Flow, Ground, Trees, Tree, M, type Clock, type V3 } from "./common";

function makePanelTexture() {
  const c = document.createElement("canvas");
  c.width = 384;
  c.height = 256;
  const g = c.getContext("2d")!;
  const grad = g.createLinearGradient(0, 0, 384, 256);
  grad.addColorStop(0, "#14285a");
  grad.addColorStop(1, "#0b1a3d");
  g.fillStyle = grad;
  g.fillRect(0, 0, 384, 256);
  const cols = 12;
  const rows = 6;
  const cw = 384 / cols;
  const rh = 256 / rows;
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      const x = i * cw + 3;
      const y = j * rh + 3;
      const gg = g.createLinearGradient(x, y, x + cw, y + rh);
      gg.addColorStop(0, "#27489a");
      gg.addColorStop(1, "#16306f");
      g.fillStyle = gg;
      g.fillRect(x, y, cw - 6, rh - 6);
      g.strokeStyle = "rgba(190,205,235,0.55)";
      g.lineWidth = 1;
      for (let k = 1; k < 4; k++) {
        g.beginPath();
        g.moveTo(x, y + ((rh - 6) / 4) * k);
        g.lineTo(x + cw - 6, y + ((rh - 6) / 4) * k);
        g.stroke();
      }
      g.strokeStyle = "rgba(220,230,250,0.9)";
      g.lineWidth = 2;
      for (const f of [0.33, 0.66]) {
        g.beginPath();
        g.moveTo(x + (cw - 6) * f, y);
        g.lineTo(x + (cw - 6) * f, y + rh - 6);
        g.stroke();
      }
    }
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}

function Panel({ x, z, tex }: { x: number; z: number; tex: THREE.Texture }) {
  const tilt = 0.55;
  return (
    <group position={[x, 0, z]}>
      <group position={[0, 1.0, 0]} rotation={[-tilt, 0, 0]}>
        <Bx s={[2.06, 0.05, 1.36]} m={M.chrome} />
        <mesh position={[0, 0.027, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[2, 1.3]} />
          <meshPhysicalMaterial map={tex} roughness={0.18} metalness={0.5} clearcoat={1} clearcoatRoughness={0.05} envMapIntensity={1.4} />
        </mesh>
      </group>
      <Pipe a={[-0.8, 0, -0.45]} b={[-0.8, 1.35, -0.45]} r={0.035} m={M.steel} />
      <Pipe a={[0.8, 0, -0.45]} b={[0.8, 1.35, -0.45]} r={0.035} m={M.steel} />
      <Pipe a={[-0.8, 0, 0.55]} b={[-0.8, 0.55, 0.5]} r={0.035} m={M.steel} />
      <Pipe a={[0.8, 0, 0.55]} b={[0.8, 0.55, 0.5]} r={0.035} m={M.steel} />
    </group>
  );
}

export default function Solar({ clock }: { clock: Clock }) {
  const tex = useMemo(makePanelTexture, []);
  const xs = [-5.5, -3.3, -1.1, 1.1, 3.3, 5.5];
  const zs = [-3.2, 0, 3.2];
  const sun: V3 = [20, 56, 36];
  const targets: V3[] = [[-3, 1.4, -3.2], [2, 1.4, 0], [4, 1.4, 3.2], [-1, 1.4, 3.2]];

  return (
    <group>
      <Ground color="#8e9462" />
      <Bx p={[0, 0.02, 0]} s={[18, 0.04, 14]} m={M.concreteDark} cast={false} />

      {/* Soleil */}
      <mesh position={sun}>
        <sphereGeometry args={[3.2, 32, 32]} />
        <meshBasicMaterial color="#fff3b0" toneMapped={false} />
      </mesh>
      <mesh position={sun}>
        <sphereGeometry args={[5, 32, 32]} />
        <meshBasicMaterial color="#ffd86b" transparent opacity={0.25} toneMapped={false} depthWrite={false} />
      </mesh>
      {targets.map((tg, i) => (
        <Flow key={i} points={[[sun[0] - 6 + i * 3, sun[1] - 4, sun[2] - 1 + i], tg]} count={12} speed={0.07 + i * 0.006} size={0.14} color="#ffe27a" clock={clock} />
      ))}

      {/* Panneaux */}
      {zs.map((z) => xs.map((x) => <Panel key={x + "_" + z} x={x} z={z} tex={tex} />))}

      {/* Câbles courant continu */}
      {zs.map((z) => {
        const path: V3[] = [[-6.6, 0.12, z], [-8.2, 0.12, z], [-8.2, 0.12, 0], [-9.3, 0.12, 0]];
        return (
          <group key={z}>
            <Flow points={path} count={10} speed={0.12} size={0.07} color="#ffb12a" clock={clock} />
          </group>
        );
      })}
      {zs.map((z) => (
        <Bx key={"c" + z} p={[-7.4, 0.04, z]} s={[1.6, 0.05, 0.08]} m={M.black} cast={false} />
      ))}
      <Bx p={[-8.2, 0.04, 0]} s={[0.08, 0.05, 6.4]} m={M.black} cast={false} />

      {/* Onduleur */}
      <Bx p={[-9.9, 0.9, 0]} s={[1.0, 1.5, 0.6]} m={M.white} />
      <Bx p={[-9.38, 1.2, 0]} s={[0.04, 0.4, 0.4]} m={M.black} cast={false} />
      <Bx p={[-9.37, 0.65, 0]} s={[0.04, 0.12, 0.12]} m={M.green}>
        <meshStandardMaterial color="#3dff7a" emissive="#3dff7a" emissiveIntensity={2} />
      </Bx>
      {/* Batterie */}
      {[2.8, 3.4, 4.0].map((z) => (
        <Bx key={z} p={[-9.9, 0.55, z]} s={[1.0, 1.0, 0.5]} m={M.steelDark} />
      ))}
      {[2.8, 3.4, 4.0].map((z) => (
        <Bx key={"l" + z} p={[-9.38, 0.75, z]} s={[0.04, 0.1, 0.3]} m={M.green}>
          <meshStandardMaterial color="#3dff7a" emissive="#3dff7a" emissiveIntensity={1.5} />
        </Bx>
      ))}
      <Flow points={[[-9.9, 0.2, 0.4], [-9.9, 0.2, 2.6]]} count={6} speed={0.12} size={0.08} color="#5dff9a" clock={clock} />

      {/* Habitation */}
      <group position={[-16, 0, 0]}>
        <Bx p={[0, 1.6, 0]} s={[5, 3.2, 5]} m={M.concreteLight} />
        <mesh position={[0, 3.2 + 1, 0]} rotation={[0, Math.PI / 4, 0]} castShadow>
          <coneGeometry args={[4.4, 2, 4]} />
          <meshStandardMaterial color="#8a4b38" roughness={0.85} />
        </mesh>
        <Bx p={[2.52, 1.0, 0]} s={[0.06, 2, 1]} m={M.wood} />
        <Bx p={[2.52, 2, 1.6]} s={[0.06, 1, 1.1]} m={M.glassDense}>
          <meshStandardMaterial color="#ffe9a0" emissive="#ffd36b" emissiveIntensity={0.9} />
        </Bx>
        <Bx p={[2.52, 2, -1.6]} s={[0.06, 1, 1.1]} m={M.glassDense}>
          <meshStandardMaterial color="#ffe9a0" emissive="#ffd36b" emissiveIntensity={0.9} />
        </Bx>
        <Cy p={[-1.5, 4.5, -1]} rt={0.25} h={1.6} m={M.brick} />
      </group>
      <Flow points={[[-10.4, 0.5, 0], [-11.4, 0.5, 0], [-12.8, 1.0, 0]]} count={8} speed={0.1} size={0.08} color="#66d8ff" clock={clock} />
      <Pipe a={[-10.4, 0.5, 0]} b={[-13.4, 0.5, 0]} r={0.04} m={M.black} />

      <Trees list={[[-24, 8], [-22, -8], [-14, -9], [-12, 9], [12, -12], [16, -8], [14, 12], [20, 4], [-4, -14], [6, -16], [-8, 14]]} />
      <Tree p={[-20, 0, 4]} s={1.3} />
    </group>
  );
}
