import { useMemo, useRef, type ReactNode } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Line, Edges } from "@react-three/drei";

export type Clock = { current: number };
export type V3 = [number, number, number];

/* ------------------------------------------------------------------ */
/* Matériaux partagés (PBR)                                            */
/* ------------------------------------------------------------------ */
const std = (color: string, roughness = 0.6, metalness = 0, extra: object = {}) =>
  new THREE.MeshStandardMaterial({ color, roughness, metalness, ...extra });

export const M = {
  concrete: std("#bcb8ae", 0.95),
  concreteDark: std("#8d8a84", 0.95),
  concreteLight: std("#dcdad3", 0.9),
  rock: std("#7b756a", 1, 0, { flatShading: true }),
  steel: std("#9aa4ae", 0.35, 0.85),
  steelDark: std("#3a4047", 0.4, 0.8),
  chrome: std("#d9dee3", 0.15, 1),
  white: std("#eef0f0", 0.4, 0.1),
  red: std("#c0392b", 0.45, 0.2),
  blue: std("#2a5d9f", 0.4, 0.35),
  green: std("#2f7d4f", 0.5, 0.2),
  yellow: std("#e8b422", 0.5, 0.2),
  orange: std("#e0701b", 0.5, 0.2),
  copper: std("#b87333", 0.3, 1),
  black: std("#15181b", 0.6, 0.3),
  rubber: std("#222426", 0.9),
  wood: std("#a9794a", 0.8),
  brick: std("#b5654a", 0.9),
  roof: std("#5a4a42", 0.85),
  porcelain: std("#8b5a3c", 0.25, 0.1),
  glass: new THREE.MeshPhysicalMaterial({
    color: "#cfe6f2",
    transparent: true,
    opacity: 0.2,
    roughness: 0.05,
    metalness: 0,
    depthWrite: false,
    side: THREE.DoubleSide,
  }),
  glassDense: new THREE.MeshPhysicalMaterial({
    color: "#cfe6f2",
    transparent: true,
    opacity: 0.38,
    roughness: 0.05,
    depthWrite: false,
    side: THREE.DoubleSide,
  }),
  waterBody: std("#2a7aa6", 0.15, 0.1, { transparent: true, opacity: 0.88 }),
};

/* ------------------------------------------------------------------ */
/* Primitives                                                          */
/* ------------------------------------------------------------------ */
type Mat = THREE.Material;
type Common = { p?: V3; rot?: V3; m?: Mat; cast?: boolean; recv?: boolean; children?: ReactNode };

export function Bx({ p = [0, 0, 0], s = [1, 1, 1], rot = [0, 0, 0], m = M.concrete, cast = true, recv = true, children }: Common & { s?: V3 }) {
  return (
    <mesh position={p} rotation={rot} material={m} castShadow={cast} receiveShadow={recv}>
      <boxGeometry args={s} />
      {children}
    </mesh>
  );
}

export function Cy({ p = [0, 0, 0], rt = 1, rb, h = 1, seg = 40, rot = [0, 0, 0], m = M.concrete, cast = true, recv = true, open = false, children }: Common & { rt?: number; rb?: number; h?: number; seg?: number; open?: boolean }) {
  return (
    <mesh position={p} rotation={rot} material={m} castShadow={cast} receiveShadow={recv}>
      <cylinderGeometry args={[rt, rb ?? rt, h, seg, 1, open]} />
      {children}
    </mesh>
  );
}

export function Sp({ p = [0, 0, 0], r = 1, m = M.steel, sc = [1, 1, 1], cast = true, phi = Math.PI * 2, theta = Math.PI }: Common & { r?: number; sc?: V3; phi?: number; theta?: number }) {
  return (
    <mesh position={p} scale={sc} material={m} castShadow={cast} receiveShadow>
      <sphereGeometry args={[r, 40, 24, 0, phi, 0, theta]} />
    </mesh>
  );
}

/** Tuyau droit entre deux points */
export function Pipe({ a, b, r = 0.15, m = M.steel, seg = 20, cast = true }: { a: V3; b: V3; r?: number; m?: Mat; seg?: number; cast?: boolean }) {
  const A = new THREE.Vector3(...a);
  const B = new THREE.Vector3(...b);
  const dir = B.clone().sub(A);
  const len = dir.length();
  const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.clone().normalize());
  const mid = A.clone().add(B).multiplyScalar(0.5);
  return (
    <mesh position={mid} quaternion={q} material={m} castShadow={cast} receiveShadow>
      <cylinderGeometry args={[r, r, len, seg]} />
    </mesh>
  );
}

/** Poutre à section rectangulaire entre deux points */
export function Beam({ a, b, w = 0.3, h = 0.1, m = M.steelDark }: { a: V3; b: V3; w?: number; h?: number; m?: Mat }) {
  const A = new THREE.Vector3(...a);
  const B = new THREE.Vector3(...b);
  const dir = B.clone().sub(A);
  const len = dir.length();
  const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 0, 1), dir.clone().normalize());
  return (
    <mesh position={A.clone().add(B).multiplyScalar(0.5)} quaternion={q} material={m} castShadow receiveShadow>
      <boxGeometry args={[w, h, len]} />
    </mesh>
  );
}

/** Tuyauterie à plusieurs segments avec coudes */
export function PolyPipe({ pts, r = 0.15, m = M.steel }: { pts: V3[]; r?: number; m?: Mat }) {
  return (
    <group>
      {pts.slice(0, -1).map((pt, i) => (
        <Pipe key={i} a={pt} b={pts[i + 1]} r={r} m={m} />
      ))}
      {pts.slice(1, -1).map((pt, i) => (
        <Sp key={"j" + i} p={pt} r={r * 1.02} m={m} />
      ))}
    </group>
  );
}

/** Rotation pilotée par l'horloge */
export function Spin({ clock, speed = 1, axis = "y", children, position, rotation }: { clock: Clock; speed?: number; axis?: "x" | "y" | "z"; children?: ReactNode; position?: V3; rotation?: V3 }) {
  const ref = useRef<THREE.Group>(null);
  useFrame(() => {
    if (ref.current) ref.current.rotation[axis] = clock.current * speed;
  });
  return (
    <group position={position} rotation={rotation}>
      <group ref={ref}>{children}</group>
    </group>
  );
}

/* ------------------------------------------------------------------ */
/* Flux de particules le long d'un chemin                              */
/* ------------------------------------------------------------------ */
export function Flow({ points, count = 20, speed = 0.1, size = 0.1, color = "#4cc3ff", clock, reverse = false }: { points: V3[]; count?: number; speed?: number; size?: number; color?: string; clock: Clock; reverse?: boolean }) {
  const ref = useRef<THREE.InstancedMesh>(null);
  const key = points.flat().join(",");
  const curve = useMemo(() => {
    const c = new THREE.CurvePath<THREE.Vector3>();
    for (let i = 0; i < points.length - 1; i++) c.add(new THREE.LineCurve3(new THREE.Vector3(...points[i]), new THREE.Vector3(...points[i + 1])));
    return c;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const v = useMemo(() => new THREE.Vector3(), []);
  useFrame(() => {
    const mesh = ref.current;
    if (!mesh) return;
    for (let i = 0; i < count; i++) {
      let u = (i / count + clock.current * speed * (reverse ? -1 : 1)) % 1;
      if (u < 0) u += 1;
      curve.getPointAt(u, v);
      dummy.position.copy(v);
      const s = Math.min(1, u * 12, (1 - u) * 12);
      dummy.scale.setScalar(Math.max(0.01, s));
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
    }
    mesh.instanceMatrix.needsUpdate = true;
  });
  return (
    <instancedMesh ref={ref} args={[undefined, undefined, count]} frustumCulled={false}>
      <sphereGeometry args={[size, 10, 10]} />
      <meshBasicMaterial color={color} toneMapped={false} />
    </instancedMesh>
  );
}

/* ------------------------------------------------------------------ */
/* Fumée / vapeur                                                      */
/* ------------------------------------------------------------------ */
export function Smoke({ position, clock, count = 28, rise = 6, spread = 0.5, size = 0.5, grow = 2.5, color = "#ffffff", opacity = 0.35, speed = 0.1, drift = [1.5, 0, 0.4] }: { position: V3; clock: Clock; count?: number; rise?: number; spread?: number; size?: number; grow?: number; color?: string; opacity?: number; speed?: number; drift?: V3 }) {
  const ref = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  useFrame(() => {
    const mesh = ref.current;
    if (!mesh) return;
    for (let i = 0; i < count; i++) {
      const u = (i / count + clock.current * speed) % 1;
      const sx = Math.sin(i * 12.9898) * spread;
      const sz = Math.cos(i * 78.233) * spread;
      dummy.position.set(sx * (0.3 + u) + drift[0] * u * u * 3, u * rise, sz * (0.3 + u) + drift[2] * u * u * 3);
      const fade = 1 - THREE.MathUtils.smoothstep(u, 0.7, 1);
      dummy.scale.setScalar(Math.max(0.001, size * (0.5 + u * grow) * fade));
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
    }
    mesh.instanceMatrix.needsUpdate = true;
  });
  return (
    <group position={position}>
      <instancedMesh ref={ref} args={[undefined, undefined, count]} frustumCulled={false}>
        <icosahedronGeometry args={[1, 2]} />
        <meshStandardMaterial color={color} transparent opacity={opacity} depthWrite={false} roughness={1} />
      </instancedMesh>
    </group>
  );
}

/* ------------------------------------------------------------------ */
/* Surface d'eau animée                                                */
/* ------------------------------------------------------------------ */
export function Water({ position, size, seg = [40, 40], amp = 0.05, clock, color = "#2f86b8", opacity = 0.9 }: { position: V3; size: [number, number]; seg?: [number, number]; amp?: number; clock: Clock; color?: string; opacity?: number }) {
  const geo = useMemo(() => new THREE.PlaneGeometry(size[0], size[1], seg[0], seg[1]), [size[0], size[1], seg[0], seg[1]]); // eslint-disable-line react-hooks/exhaustive-deps
  useFrame(() => {
    const pos = geo.attributes.position;
    const t = clock.current;
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const y = pos.getY(i);
      pos.setZ(i, amp * (Math.sin(x * 1.3 + t * 1.6) + Math.sin(y * 1.7 + t * 1.1) * 0.7 + Math.sin((x + y) * 0.7 - t * 0.8) * 0.5));
    }
    pos.needsUpdate = true;
    geo.computeVertexNormals();
  });
  return (
    <mesh geometry={geo} position={position} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
      <meshPhysicalMaterial color={color} roughness={0.08} metalness={0.1} transparent opacity={opacity} envMapIntensity={1.6} />
    </mesh>
  );
}

/* ------------------------------------------------------------------ */
/* Décor                                                               */
/* ------------------------------------------------------------------ */
export function Ground({ color = "#6f7f4f", size = 400, y = 0 }: { color?: string; size?: number; y?: number }) {
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, y, 0]} receiveShadow>
      <planeGeometry args={[size, size]} />
      <meshStandardMaterial color={color} roughness={1} />
    </mesh>
  );
}

export function Tree({ p, s = 1 }: { p: V3; s?: number }) {
  return (
    <group position={p} scale={s}>
      <Cy p={[0, 0.5, 0]} rt={0.12} rb={0.18} h={1} m={M.wood} seg={8} />
      <mesh position={[0, 1.7, 0]} castShadow>
        <coneGeometry args={[0.8, 2, 8]} />
        <meshStandardMaterial color="#2d5a35" roughness={1} />
      </mesh>
      <mesh position={[0, 2.5, 0]} castShadow>
        <coneGeometry args={[0.55, 1.5, 8]} />
        <meshStandardMaterial color="#38703f" roughness={1} />
      </mesh>
    </group>
  );
}

export function Trees({ list }: { list: [number, number, number?][] }) {
  return (
    <>
      {list.map(([x, z, s], i) => (
        <Tree key={i} p={[x, 0, z]} s={s ?? 1 + ((i * 37) % 10) / 20} />
      ))}
    </>
  );
}

export function Hill({ p, r = 20, h = 14, color = "#6b7a5a" }: { p: V3; r?: number; h?: number; color?: string }) {
  return (
    <mesh position={[p[0], p[1] + h / 2 - 0.5, p[2]]} receiveShadow castShadow>
      <coneGeometry args={[r, h, 9, 1]} />
      <meshStandardMaterial color={color} roughness={1} flatShading />
    </mesh>
  );
}

/* ------------------------------------------------------------------ */
/* Tour aéroréfrigérante                                               */
/* ------------------------------------------------------------------ */
export function CoolingTower({ position, r = 4, h = 15 }: { position: V3; r?: number; h?: number }) {
  const geo = useMemo(() => {
    const pts: THREE.Vector2[] = [];
    for (let i = 0; i <= 40; i++) {
      const t = i / 40;
      pts.push(new THREE.Vector2(r * (1 - 0.3 * Math.sin(Math.PI * t * 0.9)), t * h));
    }
    return new THREE.LatheGeometry(pts, 64);
  }, [r, h]);
  return (
    <group position={position}>
      <mesh geometry={geo} material={M.concreteLight} castShadow receiveShadow>
        <meshStandardMaterial color="#d6d3cb" roughness={0.9} side={THREE.DoubleSide} />
      </mesh>
      {/* bassin */}
      <Cy p={[0, 0.15, 0]} rt={r * 1.25} h={0.3} m={M.concreteDark} />
    </group>
  );
}

/* ------------------------------------------------------------------ */
/* Transformateur + pylônes + lignes                                   */
/* ------------------------------------------------------------------ */
export function Transformer({ position }: { position: V3 }) {
  return (
    <group position={position}>
      <Bx p={[0, 0.8, 0]} s={[2, 1.4, 1.3]} m={M.green} />
      {[-0.6, -0.3, 0, 0.3, 0.6].map((x) => (
        <Bx key={x} p={[x * 1.4, 0.8, 0.75]} s={[0.12, 1.2, 0.3]} m={M.steelDark} />
      ))}
      <Cy p={[0, 1.75, -0.3]} rt={0.22} h={1.9} rot={[0, 0, Math.PI / 2]} m={M.green} />
      {[-0.6, 0, 0.6].map((x) => (
        <group key={x} position={[x, 1.5, 0.2]}>
          <Cy p={[0, 0.3, 0]} rt={0.06} rb={0.12} h={0.6} m={M.porcelain} seg={12} />
          {[0.1, 0.25, 0.4].map((y) => (
            <Cy key={y} p={[0, y, 0]} rt={0.16} h={0.04} m={M.porcelain} seg={12} />
          ))}
        </group>
      ))}
      <Bx p={[0, 0.06, 0]} s={[2.4, 0.12, 1.7]} m={M.concreteDark} />
    </group>
  );
}

export function Pylon({ position, h = 9 }: { position: V3; h?: number }) {
  const base = 1.1;
  const top = 0.22;
  const c = (k: number, sx: number, sz: number): V3 => {
    const w = base + (top - base) * k;
    return [sx * w, k * h, sz * w];
  };
  const corners: [number, number][] = [[1, 1], [1, -1], [-1, -1], [-1, 1]];
  const levels = [0, 0.33, 0.66, 1];
  const armY = h * 0.86;
  return (
    <group position={position}>
      {corners.map(([sx, sz], i) => (
        <Pipe key={i} a={c(0, sx, sz)} b={c(1, sx, sz)} r={0.07} m={M.steel} />
      ))}
      {levels.slice(0, -1).map((k, li) => {
        const k2 = levels[li + 1];
        return corners.map(([sx, sz], i) => {
          const [nx, nz] = corners[(i + 1) % 4];
          return (
            <group key={li + "-" + i}>
              <Pipe a={c(k2, sx, sz)} b={c(k2, nx, nz)} r={0.035} m={M.steel} />
              <Pipe a={c(k, sx, sz)} b={c(k2, nx, nz)} r={0.03} m={M.steel} />
            </group>
          );
        });
      })}
      <Pipe a={[0, armY, -2]} b={[0, armY, 2]} r={0.08} m={M.steel} />
      <Pipe a={[0, armY, -2]} b={[0, h, 0]} r={0.035} m={M.steel} />
      <Pipe a={[0, armY, 2]} b={[0, h, 0]} r={0.035} m={M.steel} />
      <Pipe a={[0, armY - 0.05, 0]} b={[0, h + 0.8, 0]} r={0.05} m={M.steel} />
      {[-1.6, 0, 1.6].map((z) => (
        <Cy key={z} p={[0, armY - 0.3, z]} rt={0.07} h={0.6} m={M.porcelain} seg={10} />
      ))}
    </group>
  );
}

export function catenary(a: V3, b: V3, sag = 0.8, n = 16): V3[] {
  const out: V3[] = [];
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    out.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t - sag * 4 * t * (1 - t), a[2] + (b[2] - a[2]) * t]);
  }
  return out;
}

export function PowerLine({ start, x1, x2, z, h = 9, clock }: { start: V3; x1: number; x2: number; z: number; h?: number; clock: Clock }) {
  const armY = h * 0.86 - 0.6;
  const entry = catenary(start, [x1, armY, z], 0.4);
  return (
    <group>
      <Pylon position={[x1, 0, z]} h={h} />
      <Pylon position={[x2, 0, z]} h={h} />
      <Line points={entry} color="#2a2a2a" lineWidth={1.5} />
      <Flow points={entry} count={10} speed={0.12} size={0.09} color="#ffd24a" clock={clock} />
      {[-1.6, 0, 1.6].map((dz) => {
        const pts = catenary([x1, armY, z + dz], [x2, armY, z + dz], 1.3, 24);
        return (
          <group key={dz}>
            <Line points={pts} color="#2a2a2a" lineWidth={1.5} />
            <Flow points={pts} count={22} speed={0.1} size={0.09} color="#ffd24a" clock={clock} />
          </group>
        );
      })}
    </group>
  );
}

/** Boîtier vitré (vue en transparence) avec arêtes */
export function GlassHall({ p, s }: { p: V3; s: V3 }) {
  return (
    <mesh position={p} material={M.glass}>
      <boxGeometry args={s} />
      <Edges color="#e8f1f6" threshold={15} />
    </mesh>
  );
}
