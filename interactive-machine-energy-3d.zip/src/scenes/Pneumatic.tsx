import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Bx, Cy, Sp, PolyPipe, Spin, Flow, M, type Clock, type V3 } from "./common";

const ease = (x: number) => x * x * (3 - 2 * x);
/** cycle du vérin : retourne avancée 0..1, sortie, rentrée */
export function cycle(t: number) {
  const p = (t * 0.12) % 1;
  let adv = 0;
  if (p < 0.42) adv = ease(p / 0.42);
  else if (p < 0.52) adv = 1;
  else if (p < 0.94) adv = 1 - ease((p - 0.52) / 0.42);
  return { p, adv, ext: p < 0.42, ret: p > 0.52 && p < 0.94 };
}

const TRAVEL = 2.2;
const BARREL_X0 = 3.7;

function Gauge({ position, clock }: { position: V3; clock: Clock }) {
  const needle = useRef<THREE.Group>(null);
  useFrame(() => {
    if (needle.current) needle.current.rotation.z = -0.6 - (0.55 + Math.sin(clock.current * 0.7) * 0.12) * 3.6;
  });
  return (
    <group position={position}>
      <Cy rt={0.24} h={0.1} rot={[Math.PI / 2, 0, 0]} m={M.chrome} />
      <mesh position={[0, 0, 0.055]}>
        <circleGeometry args={[0.2, 32]} />
        <meshStandardMaterial color="#f5f5f0" roughness={0.6} />
      </mesh>
      <group ref={needle} position={[0, 0, 0.07]}>
        <Bx p={[0, 0.08, 0]} s={[0.015, 0.16, 0.01]} m={M.red} cast={false} />
      </group>
      {Array.from({ length: 9 }).map((_, i) => {
        const a = -2.3 + i * 0.58;
        return <Bx key={i} p={[Math.sin(a) * 0.17, Math.cos(a) * 0.17, 0.06]} s={[0.01, 0.03, 0.005]} rot={[0, 0, -a]} m={M.black} cast={false} />;
      })}
    </group>
  );
}

function Actuator({ clock }: { clock: Clock }) {
  const mov = useRef<THREE.Group>(null);
  const rearG = useRef<THREE.Group>(null);
  const frontG = useRef<THREE.Group>(null);
  const rearM = useRef<THREE.Mesh>(null);
  const frontM = useRef<THREE.Mesh>(null);
  const rearMat = useRef<THREE.MeshStandardMaterial>(null);
  const frontMat = useRef<THREE.MeshStandardMaterial>(null);
  const solA = useRef<THREE.MeshStandardMaterial>(null);
  const solB = useRef<THREE.MeshStandardMaterial>(null);
  const crate = useRef<THREE.Mesh>(null);
  const fA = useRef<THREE.Group>(null);
  const fB = useRef<THREE.Group>(null);

  useFrame(() => {
    const { p, adv, ext, ret } = cycle(clock.current);
    const px = BARREL_X0 + 0.25 + adv * TRAVEL; // position piston
    if (mov.current) mov.current.position.x = adv * TRAVEL;
    const rearLen = px - 0.1 - BARREL_X0;
    const frontEnd = BARREL_X0 + 3.0;
    const frontLen = frontEnd - (px + 0.1);
    if (rearG.current && rearM.current) {
      rearG.current.position.x = BARREL_X0 + rearLen / 2;
      rearM.current.scale.y = Math.max(0.01, rearLen);
    }
    if (frontG.current && frontM.current) {
      frontG.current.position.x = px + 0.1 + frontLen / 2;
      frontM.current.scale.y = Math.max(0.01, frontLen);
    }
    if (rearMat.current) rearMat.current.opacity = ext ? 0.7 : 0.1;
    if (rearMat.current) rearMat.current.emissiveIntensity = ext ? 1.6 : 0.1;
    if (frontMat.current) frontMat.current.opacity = ret ? 0.7 : 0.1;
    if (frontMat.current) frontMat.current.emissiveIntensity = ret ? 1.6 : 0.1;
    if (solA.current) solA.current.emissiveIntensity = ext ? 2.5 : 0;
    if (solB.current) solB.current.emissiveIntensity = ret ? 2.5 : 0;
    if (fA.current) fA.current.visible = ext;
    if (fB.current) fB.current.visible = ret;
    if (crate.current) {
      const pAdv = p < 0.52 ? adv : 1;
      const exit = p > 0.62 ? ((p - 0.62) / 0.38) * 3.2 : 0;
      crate.current.position.x = 7.95 + pAdv * TRAVEL + exit;
      const s = Math.min(1, p / 0.08) * (p > 0.92 ? (1 - p) / 0.08 : 1);
      crate.current.scale.setScalar(Math.max(0.001, s));
    }
  });

  const tubeA: V3[] = [[1.1, 1.7, 0.36], [1.1, 2.2, 0.9], [3.9, 2.2, 0.9], [3.9, 2.2, 0], [3.9, 1.9, 0]];
  const tubeB: V3[] = [[1.7, 1.7, 0.36], [1.7, 1.9, 1.3], [6.3, 1.9, 1.3], [6.3, 1.9, 0]];
  const clockRef = clock;

  return (
    <group>
      {/* Tubes */}
      <PolyPipe pts={tubeA} r={0.06} m={M.blue} />
      <PolyPipe pts={tubeB} r={0.06} m={M.orange} />
      <group ref={fA}>
        <Flow points={tubeA} count={9} speed={0.4} size={0.07} color="#66e0ff" clock={clockRef} />
      </group>
      <group ref={fB}>
        <Flow points={tubeB} count={9} speed={0.4} size={0.07} color="#66e0ff" clock={clockRef} />
      </group>

      {/* Fût du vérin */}
      <Cy p={[BARREL_X0 + 1.5, 1.5, 0]} rt={0.4} h={3} rot={[0, 0, Math.PI / 2]} m={M.glassDense} cast={false} />
      <Cy p={[BARREL_X0 - 0.07, 1.5, 0]} rt={0.46} h={0.14} rot={[0, 0, Math.PI / 2]} m={M.steel} />
      <Cy p={[BARREL_X0 + 3.07, 1.5, 0]} rt={0.46} h={0.14} rot={[0, 0, Math.PI / 2]} m={M.steel} />
      {[0.3, 2.7].map((o) => (
        <Cy key={o} p={[BARREL_X0 + o, 1.5, 0]} rt={0.43} h={0.12} rot={[0, 0, Math.PI / 2]} m={M.steelDark} />
      ))}
      {[[0.38, 0.38], [0.38, -0.38], [-0.38, 0.38], [-0.38, -0.38]].map(([y, z], i) => (
        <Cy key={i} p={[BARREL_X0 + 1.5, 1.5 + y * 1.0, z]} rt={0.02} h={3.15} rot={[0, 0, Math.PI / 2]} m={M.chrome} cast={false} />
      ))}
      {/* Chambres d'air */}
      <group ref={rearG} position={[BARREL_X0 + 0.5, 1.5, 0]} rotation={[0, 0, Math.PI / 2]}>
        <mesh ref={rearM}>
          <cylinderGeometry args={[0.37, 0.37, 1, 28]} />
          <meshStandardMaterial ref={rearMat} color="#35c8ff" emissive="#35c8ff" emissiveIntensity={1} transparent opacity={0.5} depthWrite={false} />
        </mesh>
      </group>
      <group ref={frontG} position={[BARREL_X0 + 2.5, 1.5, 0]} rotation={[0, 0, Math.PI / 2]}>
        <mesh ref={frontM}>
          <cylinderGeometry args={[0.37, 0.37, 1, 28]} />
          <meshStandardMaterial ref={frontMat} color="#ff9a3c" emissive="#ff9a3c" emissiveIntensity={1} transparent opacity={0.5} depthWrite={false} />
        </mesh>
      </group>

      {/* Piston + tige + pousseur */}
      <group ref={mov}>
        <Cy p={[BARREL_X0 + 0.25, 1.5, 0]} rt={0.36} h={0.2} rot={[0, 0, Math.PI / 2]} m={M.steelDark} />
        <Cy p={[BARREL_X0 + 0.25, 1.5, 0]} rt={0.37} h={0.05} rot={[0, 0, Math.PI / 2]} m={M.black} />
        <Cy p={[BARREL_X0 + 0.25 + 1.6, 1.5, 0]} rt={0.1} h={3.2} rot={[0, 0, Math.PI / 2]} m={M.chrome} />
        <Bx p={[BARREL_X0 + 0.25 + 3.2 + 0.15, 1.5, 0]} s={[0.3, 0.7, 1.0]} m={M.yellow} />
      </group>

      {/* Distributeur 5/2 */}
      <group position={[1.4, 1.7, 0]}>
        <Bx s={[1.2, 0.7, 0.7]} m={M.steel} />
        <Bx p={[-0.78, 0, 0]} s={[0.35, 0.5, 0.5]} m={M.black}>
          <meshStandardMaterial color="#222" />
        </Bx>
        <mesh position={[-0.78, 0, 0.26]}>
          <boxGeometry args={[0.12, 0.12, 0.03]} />
          <meshStandardMaterial ref={solA} color="#1a3a1a" emissive="#3dff7a" emissiveIntensity={0} />
        </mesh>
        <Bx p={[0.78, 0, 0]} s={[0.35, 0.5, 0.5]} m={M.black} />
        <mesh position={[0.78, 0, 0.26]}>
          <boxGeometry args={[0.12, 0.12, 0.03]} />
          <meshStandardMaterial ref={solB} color="#3a2a10" emissive="#ffa63d" emissiveIntensity={0} />
        </mesh>
        <Cy p={[0, -0.5, 0.0]} rt={0.14} h={0.3} m={M.copper} />
        <Bx p={[0, -0.9, 0]} s={[0.5, 0.2, 0.5]} m={M.steelDark} cast={false} />
        <Bx p={[-0.4, -0.55, 0]} s={[0.08, 1.0, 0.08]} m={M.steelDark} />
        <Bx p={[0.4, -0.55, 0]} s={[0.08, 1.0, 0.08]} m={M.steelDark} />
      </group>

      {/* Table, caisse et rampe */}
      <Bx p={[11, 1.05, 0]} s={[8, 0.12, 2]} m={M.steel} />
      {[7.2, 14.4].map((x) => [-0.8, 0.8].map((z) => <Bx key={x + "_" + z} p={[x, 0.5, z]} s={[0.12, 1.0, 0.12]} m={M.steelDark} />))}
      {Array.from({ length: 12 }).map((_, i) => (
        <Cy key={i} p={[7.2 + i * 0.6, 1.14, 0]} rt={0.05} h={1.9} rot={[Math.PI / 2, 0, 0]} m={M.chrome} cast={false} />
      ))}
      <mesh ref={crate} position={[7.95, 1.68, 0]} castShadow>
        <boxGeometry args={[0.9, 0.9, 0.9]} />
        <meshStandardMaterial color="#b98a55" roughness={0.85} />
      </mesh>
      {/* support du vérin */}
      <Bx p={[BARREL_X0 + 1.5, 0.98, 0]} s={[3.2, 0.1, 1.0]} m={M.steelDark} />
      {[BARREL_X0 + 0.2, BARREL_X0 + 2.8].map((x) => (
        <group key={x}>
          <Bx p={[x, 1.2, 0]} s={[0.15, 0.4, 0.8]} m={M.steelDark} />
          <Bx p={[x, 0.55, 0.0]} s={[0.1, 0.9, 0.1]} m={M.steelDark} />
        </group>
      ))}
    </group>
  );
}

export default function Pneumatic({ clock }: { clock: Clock }) {
  const mainLine: V3[] = [[-4.6, 2.1, 0], [-4.6, 2.6, 0], [1.4, 2.6, 0], [1.4, 2.06, 0]];
  const shake = useRef<THREE.Group>(null);
  useFrame(() => {
    if (shake.current) shake.current.position.y = Math.sin(clock.current * 60) * 0.004;
  });
  return (
    <group>
      {/* Atelier */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[200, 200]} />
        <meshStandardMaterial color="#6c7076" roughness={0.85} />
      </mesh>
      {Array.from({ length: 20 }).map((_, i) => (
        <Bx key={i} p={[-40 + i * 4.2, 0.005, 0]} s={[0.04, 0.01, 200]} m={M.concreteDark} cast={false} />
      ))}
      <Bx p={[2, 0.01, 4.2]} s={[40, 0.01, 0.18]} m={M.yellow} cast={false} />
      <Bx p={[2, 0.01, -4.2]} s={[40, 0.01, 0.18]} m={M.yellow} cast={false} />
      {/* mur de fond */}
      <Bx p={[3, 5, -9]} s={[50, 10, 0.4]} m={M.concreteLight} />
      <Bx p={[3, 1.5, -8.75]} s={[50, 3, 0.1]} m={M.blue} cast={false} />
      {[-14, 0, 14].map((x) => (
        <Bx key={x} p={[x, 6, -8.78]} s={[5, 2.6, 0.06]} m={M.glassDense}>
          <meshStandardMaterial color="#bfe4ff" emissive="#bfe4ff" emissiveIntensity={0.6} />
        </Bx>
      ))}

      {/* Compresseur */}
      <group position={[-6, 0, 0]}>
        {[-1.4, 1.4].map((x) => (
          <group key={x}>
            <Bx p={[x, 0.35, 0.35]} s={[0.2, 0.7, 0.12]} m={M.steelDark} />
            <Bx p={[x, 0.35, -0.35]} s={[0.2, 0.7, 0.12]} m={M.steelDark} />
          </group>
        ))}
        <Cy p={[0, 1.4, 0]} rt={0.7} h={3} rot={[0, 0, Math.PI / 2]} m={M.red} />
        <Sp p={[-1.5, 1.4, 0]} r={0.7} m={M.red} />
        <Sp p={[1.5, 1.4, 0]} r={0.7} m={M.red} />
        <Cy p={[0, 1.4, 0]} rt={0.71} h={0.05} rot={[0, 0, Math.PI / 2]} m={M.steelDark} />
        <Gauge position={[1.1, 1.9, 0.72]} clock={clock} />
        {/* groupe motopompe */}
        <group ref={shake} position={[0, 2.1, 0]}>
          <Bx p={[0, 0.05, 0]} s={[2.2, 0.1, 0.9]} m={M.steelDark} />
          <Cy p={[-0.6, 0.5, 0]} rt={0.38} h={1.0} rot={[Math.PI / 2, 0, 0]} m={M.blue} />
          {Array.from({ length: 8 }).map((_, i) => (
            <Cy key={i} p={[-0.6, 0.5, -0.45 + i * 0.13]} rt={0.4} h={0.03} rot={[Math.PI / 2, 0, 0]} m={M.blue} />
          ))}
          <Bx p={[0.75, 0.55, 0]} s={[0.8, 1.0, 0.7]} m={M.steel} />
          {[0, 1, 2, 3, 4].map((i) => (
            <Bx key={i} p={[0.75, 0.2 + i * 0.2, 0.37]} s={[0.84, 0.05, 0.1]} m={M.steelDark} />
          ))}
          <Cy p={[0.75, 1.15, 0]} rt={0.14} h={0.25} m={M.black} />
          {/* Volant moteur & courroie */}
          <Cy p={[0.0, 0.5, 0.52]} rt={0.5} h={0.08} rot={[Math.PI / 2, 0, 0]} m={M.glassDense} cast={false} />
          <Spin clock={clock} speed={12} axis="z" position={[-0.35, 0.5, 0.52]}>
            <Cy rt={0.2} h={0.1} rot={[Math.PI / 2, 0, 0]} m={M.chrome} />
            <Bx p={[0.12, 0, 0]} s={[0.2, 0.04, 0.12]} m={M.red} />
          </Spin>
          <Spin clock={clock} speed={5} axis="z" position={[0.55, 0.5, 0.52]}>
            <Cy rt={0.32} h={0.1} rot={[Math.PI / 2, 0, 0]} m={M.chrome} />
            <Bx p={[0.2, 0, 0]} s={[0.3, 0.05, 0.12]} m={M.red} />
            <Bx p={[-0.2, 0, 0]} s={[0.3, 0.05, 0.12]} m={M.red} />
          </Spin>
        </group>
      </group>

      {/* Ligne principale + FRL */}
      <PolyPipe pts={mainLine} r={0.09} m={M.steel} />
      <Flow points={mainLine} count={16} speed={0.2} size={0.06} color="#66e0ff" clock={clock} />
      {[-3.1, -2.4, -1.7].map((x, i) => (
        <group key={x} position={[x, 2.15, 0]}>
          <Cy p={[0, 0.3, 0]} rt={0.22} h={0.3} m={M.steel} />
          <Cy p={[0, -0.05, 0]} rt={0.2} h={0.45} m={M.glassDense} cast={false} />
          <Cy p={[0, -0.3, 0]} rt={0.22} h={0.06} m={M.steel} />
          {i === 1 && <Cy p={[0, 0.58, 0]} rt={0.1} h={0.25} m={M.yellow} />}
          {i === 2 && <Cy p={[0, -0.12, 0]} rt={0.17} h={0.2} m={M.orange} cast={false} />}
        </group>
      ))}
      <Gauge position={[-2.4, 2.8, 0.3]} clock={clock} />

      <Actuator clock={clock} />
    </group>
  );
}
