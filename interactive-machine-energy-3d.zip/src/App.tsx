import { useCallback, useEffect, useRef, useState } from "react";
import Viewer, { type Focus } from "./Viewer";
import { ENERGIES } from "./data";

type Tab = "def" | "principe" | "schema" | "usage";
const TABS: { id: Tab; label: string; icon: string }[] = [
  { id: "def", label: "Définition", icon: "📖" },
  { id: "principe", label: "Principe", icon: "⚙️" },
  { id: "schema", label: "Schéma + Vidéo", icon: "🎬" },
  { id: "usage", label: "Utilisation", icon: "🏭" },
];

const GROUPS = ["Énergie électrique", "Énergie solaire", "Énergie éolienne", "Énergie pneumatique"];

function IconBtn({ onClick, active, title, children }: { onClick: () => void; active?: boolean; title: string; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      title={title}
      className={`flex h-9 min-w-9 items-center justify-center gap-1.5 rounded-lg px-2.5 text-sm font-medium transition-colors ${active ? "bg-white text-slate-900" : "bg-white/10 text-white hover:bg-white/20"}`}
    >
      {children}
    </button>
  );
}

export default function App() {
  const [idx, setIdx] = useState(0);
  const energy = ENERGIES[idx];
  const [tab, setTab] = useState<Tab>("def");
  const [step, setStep] = useState<number | null>(null);
  const [playing, setPlaying] = useState(true);
  const [speed, setSpeed] = useState(1);
  const [labels, setLabels] = useState(true);
  const [tour, setTour] = useState(false);
  const clock = useRef(0);
  const [focus, setFocus] = useState<Focus>({ ...ENERGIES[0].overview, key: 0 });

  const selectEnergy = (i: number) => {
    setIdx(i);
    setStep(null);
    setTour(false);
    clock.current = 0;
    setFocus({ ...ENERGIES[i].overview, key: Date.now() });
  };

  const goStep = useCallback(
    (i: number) => {
      setStep(i);
      const s = energy.steps[i];
      setFocus({ cam: s.cam, target: s.target, key: Date.now() });
    },
    [energy]
  );

  const selectFromScene = (i: number) => {
    setTour(false);
    setTab("schema");
    goStep(i);
  };

  const reset = () => {
    setStep(null);
    setTour(false);
    setFocus({ ...energy.overview, key: Date.now() });
  };

  useEffect(() => {
    if (!tour) return;
    const id = setInterval(() => {
      setStep((cur) => {
        const next = cur === null ? 0 : (cur + 1) % energy.steps.length;
        const s = energy.steps[next];
        setFocus({ cam: s.cam, target: s.target, key: Date.now() });
        return next;
      });
    }, 6500);
    return () => clearInterval(id);
  }, [tour, energy]);

  const startTour = () => {
    if (tour) {
      setTour(false);
      return;
    }
    setTab("schema");
    setTour(true);
    goStep(0);
  };

  const activeStep = step !== null ? energy.steps[step] : null;

  return (
    <div className="flex min-h-screen flex-col bg-slate-950 text-slate-100 lg:h-screen">
      {/* En-tête */}
      <header className="border-b border-white/10 bg-slate-900/80 px-4 py-3 backdrop-blur">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-lg font-bold leading-tight sm:text-xl">
              Exposé · Types d'énergie <span className="text-slate-400">— Fonction « Alimenter »</span>
            </h1>
            <p className="text-xs text-slate-400">Machines énergétiques en 3D interactive : explorez, tournez, zoomez.</p>
          </div>
        </div>
        <nav className="mt-3 flex gap-4 overflow-x-auto pb-1">
          {GROUPS.map((g) => {
            const items = ENERGIES.map((e, i) => ({ e, i })).filter(({ e }) => e.group === g);
            return (
              <div key={g} className="shrink-0">
                <div className="mb-1 text-[10px] font-semibold uppercase tracking-wider text-slate-500">{g}</div>
                <div className="flex gap-1.5">
                  {items.map(({ e, i }) => (
                    <button
                      key={e.id}
                      onClick={() => selectEnergy(i)}
                      className={`flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-sm font-medium transition-all ${i === idx ? "text-slate-900" : "border-white/10 bg-white/5 text-slate-300 hover:bg-white/10"}`}
                      style={i === idx ? { background: e.accent, borderColor: e.accent } : undefined}
                    >
                      <span>{e.emoji}</span>
                      {e.short}
                    </button>
                  ))}
                </div>
              </div>
            );
          })}
        </nav>
      </header>

      <main className="flex min-h-0 flex-1 flex-col lg:flex-row">
        {/* Zone 3D */}
        <section className="relative h-[62vh] min-h-[360px] flex-1 lg:h-auto">
          <div className="absolute inset-0 isolate">
            <Viewer energy={energy} clock={clock} playing={playing} speed={speed} labels={labels} focus={focus} active={step} onSelect={selectFromScene} />
          </div>

          {/* Titre */}
          <div className="pointer-events-none absolute left-3 top-3 z-30 max-w-[70%] rounded-xl bg-slate-900/75 px-4 py-2.5 backdrop-blur">
            <div className="flex items-center gap-2 text-base font-bold sm:text-lg">
              <span>{energy.emoji}</span>
              {energy.name}
            </div>
            <div className="text-xs" style={{ color: energy.accent }}>
              {energy.tagline}
            </div>
          </div>
          <div className="pointer-events-none absolute right-3 top-3 z-30 hidden rounded-lg bg-slate-900/60 px-3 py-1.5 text-[11px] text-slate-300 backdrop-blur sm:block">
            🖱️ Glisser : tourner · Molette : zoom · Clic droit : déplacer
          </div>

          {/* Sous-titre (étape) */}
          {activeStep && (
            <div className="absolute bottom-16 left-3 right-3 z-30 mx-auto max-w-xl rounded-xl bg-slate-900/85 p-3.5 shadow-xl backdrop-blur sm:left-3 sm:right-auto sm:mx-0">
              <div className="mb-1 flex items-center gap-2 text-sm font-bold">
                <span className="flex h-6 w-6 items-center justify-center rounded-full text-xs text-slate-900" style={{ background: energy.accent }}>
                  {(step ?? 0) + 1}
                </span>
                {activeStep.title}
              </div>
              <p className="text-xs leading-relaxed text-slate-300 sm:text-sm">{activeStep.text}</p>
            </div>
          )}

          {/* Contrôles vidéo */}
          <div className="absolute bottom-3 left-1/2 z-30 flex -translate-x-1/2 flex-wrap items-center justify-center gap-1.5 rounded-xl bg-slate-900/80 p-1.5 backdrop-blur">
            <IconBtn onClick={() => setPlaying((p) => !p)} title={playing ? "Pause" : "Lecture"} active={!playing}>
              {playing ? "⏸" : "▶"}
            </IconBtn>
            <div className="flex items-center rounded-lg bg-white/10 p-0.5">
              {[0.5, 1, 2].map((s) => (
                <button key={s} onClick={() => setSpeed(s)} className={`h-8 rounded-md px-2 text-xs font-semibold ${speed === s ? "bg-white text-slate-900" : "text-white hover:bg-white/10"}`}>
                  {s}×
                </button>
              ))}
            </div>
            <IconBtn onClick={startTour} title="Visite guidée automatique" active={tour}>
              🎬 <span className="hidden sm:inline">{tour ? "Arrêter" : "Visite guidée"}</span>
            </IconBtn>
            <IconBtn onClick={() => setLabels((l) => !l)} title="Afficher / masquer les repères" active={labels}>
              📍
            </IconBtn>
            <IconBtn onClick={reset} title="Vue d'ensemble">
              🎯
            </IconBtn>
          </div>
        </section>

        {/* Panneau pédagogique */}
        <aside className="flex w-full flex-col border-t border-white/10 bg-slate-900 lg:w-[430px] lg:border-l lg:border-t-0">
          <div className="flex border-b border-white/10">
            {TABS.map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`flex-1 border-b-2 px-1 py-3 text-[11px] font-semibold transition-colors sm:text-xs ${tab === t.id ? "text-white" : "border-transparent text-slate-400 hover:text-slate-200"}`}
                style={tab === t.id ? { borderColor: energy.accent } : undefined}
              >
                <div className="text-base">{t.icon}</div>
                {t.label}
              </button>
            ))}
          </div>

          <div className="min-h-0 flex-1 overflow-y-auto p-5">
            {tab === "def" && (
              <div className="space-y-5">
                <div>
                  <div className="mb-1 text-[11px] font-semibold uppercase tracking-wider text-slate-500">{energy.group}</div>
                  <h2 className="text-2xl font-bold">{energy.name}</h2>
                </div>
                <div className="space-y-3 text-sm leading-relaxed text-slate-300">
                  {energy.definition.map((p, i) => (
                    <p key={i}>{p}</p>
                  ))}
                </div>
                <div>
                  <h3 className="mb-2 text-sm font-bold">Chaîne d'énergie</h3>
                  <div className="space-y-1.5">
                    {energy.chain.map((c, i) => (
                      <div key={i}>
                        <div className="flex items-center gap-3 rounded-lg border border-white/10 bg-white/5 px-3 py-2">
                          <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-xs font-bold text-slate-900" style={{ background: energy.accent }}>
                            {i + 1}
                          </span>
                          <div>
                            <div className="text-[10px] uppercase tracking-wider text-slate-500">{c.label}</div>
                            <div className="text-sm font-medium">{c.value}</div>
                          </div>
                        </div>
                        {i < energy.chain.length - 1 && <div className="ml-6 text-slate-600">↓</div>}
                      </div>
                    ))}
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {energy.facts.map((f) => (
                    <div key={f.label} className="rounded-lg bg-white/5 p-3">
                      <div className="text-[11px] text-slate-500">{f.label}</div>
                      <div className="text-sm font-bold" style={{ color: energy.accent }}>
                        {f.value}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {tab === "principe" && (
              <div className="space-y-4">
                <h2 className="text-xl font-bold">Principe de fonctionnement</h2>
                <ol className="space-y-3">
                  {energy.principle.map((p, i) => (
                    <li key={i} className="flex gap-3 rounded-xl border border-white/10 bg-white/5 p-3.5">
                      <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-sm font-bold text-slate-900" style={{ background: energy.accent }}>
                        {i + 1}
                      </span>
                      <p className="text-sm leading-relaxed text-slate-300">{p}</p>
                    </li>
                  ))}
                </ol>
                <button onClick={() => setTab("schema")} className="w-full rounded-xl py-2.5 text-sm font-bold text-slate-900" style={{ background: energy.accent }}>
                  Voir le schéma en 3D →
                </button>
              </div>
            )}

            {tab === "schema" && (
              <div className="space-y-4">
                <h2 className="text-xl font-bold">Schéma + Vidéo</h2>
                <p className="text-sm text-slate-400">Cliquez sur une étape (ou sur un repère numéroté dans la scène) : la caméra s'y déplace. Lancez la visite guidée pour une présentation automatique.</p>
                <button onClick={startTour} className="flex w-full items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-bold text-slate-900" style={{ background: energy.accent }}>
                  {tour ? "⏹ Arrêter la visite" : "🎬 Lancer la visite guidée"}
                </button>
                <ul className="space-y-2">
                  {energy.steps.map((s, i) => (
                    <li key={i}>
                      <button
                        onClick={() => {
                          setTour(false);
                          goStep(i);
                        }}
                        className={`flex w-full gap-3 rounded-xl border p-3 text-left transition-colors ${step === i ? "bg-white/10" : "border-white/10 bg-white/5 hover:bg-white/10"}`}
                        style={step === i ? { borderColor: energy.accent } : undefined}
                      >
                        <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-sm font-bold text-slate-900" style={{ background: step === i ? energy.accent : "#e2e8f0" }}>
                          {i + 1}
                        </span>
                        <span>
                          <span className="block text-sm font-semibold">{s.title}</span>
                          <span className="mt-0.5 block text-xs leading-relaxed text-slate-400">{s.text}</span>
                        </span>
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {tab === "usage" && (
              <div className="space-y-4">
                <h2 className="text-xl font-bold">Domaines d'utilisation</h2>
                <div className="space-y-3">
                  {energy.uses.map((u) => (
                    <div key={u.title} className="flex gap-3 rounded-xl border border-white/10 bg-white/5 p-3.5">
                      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-white/10 text-2xl">{u.icon}</div>
                      <div>
                        <div className="text-sm font-semibold">{u.title}</div>
                        <p className="mt-0.5 text-xs leading-relaxed text-slate-400">{u.text}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </aside>
      </main>
    </div>
  );
}
