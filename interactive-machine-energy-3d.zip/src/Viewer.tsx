import { Suspense, memo, useEffect, useRef } from "react";
import * as THREE from "three";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { OrbitControls, Sky, Environment, Lightformer, Html } from "@react-three/drei";
import Hydro from "./scenes/Hydro";
import Thermal from "./scenes/Thermal";
import Nuclear from "./scenes/Nuclear";
import Solar from "./scenes/Solar";
import Wind from "./scenes/Wind";
import Pneumatic from "./scenes/Pneumatic";
import type { Clock, V3 } from "./scenes/common";
import type { Energy } from "./data";

const SCENES = { hydro: memo(Hydro), thermal: memo(Thermal), nuclear: memo(Nuclear), solar: memo(Solar), wind: memo(Wind), pneumatic: memo(Pneumatic) };

export type Focus = { cam: V3; target: V3; key: number };

function ClockDriver({ clock, playing, speed }: { clock: Clock; playing: boolean; speed: number }) {
  useFrame((_, d) => {
    if (playing) clock.current += Math.min(d, 0.05) * speed;
  });
  return null;
}

function CameraRig({ focus }: { focus: Focus }) {
  const { camera } = useThree();
  const controls = useThree((s) => s.controls) as unknown as { target: THREE.Vector3; update: () => void } | null;
  const anim = useRef({ t: 1, fp: new THREE.Vector3(), ft: new THREE.Vector3(), tp: new THREE.Vector3(), tt: new THREE.Vector3() });
  useEffect(() => {
    if (!controls) return;
    const a = anim.current;
    a.t = 0;
    a.fp.copy(camera.position);
    a.ft.copy(controls.target);
    a.tp.set(...focus.cam);
    a.tt.set(...focus.target);
  }, [focus, controls, camera]);
  useFrame((_, d) => {
    const a = anim.current;
    if (a.t >= 1 || !controls) return;
    a.t = Math.min(1, a.t + d / 1.6);
    const e = a.t < 0.5 ? 4 * a.t ** 3 : 1 - (-2 * a.t + 2) ** 3 / 2;
    camera.position.lerpVectors(a.fp, a.tp, e);
    controls.target.lerpVectors(a.ft, a.tt, e);
    controls.update();
  });
  return null;
}

function Hotspots({ energy, active, onSelect }: { energy: Energy; active: number | null; onSelect: (i: number) => void }) {
  return (
    <>
      {energy.steps.map((s, i) => (
        <Html key={energy.id + i} position={s.pos} center zIndexRange={[10, 0]}>
          <button
            onClick={() => onSelect(i)}
            className="group relative flex items-center"
            style={{ transform: "translateY(-2px)" }}
          >
            <span
              className="flex h-8 w-8 items-center justify-center rounded-full border-2 border-white text-sm font-bold text-slate-900 shadow-lg transition-transform group-hover:scale-125"
              style={{
                background: active === i ? energy.accent : "rgba(255,255,255,0.92)",
                boxShadow: active === i ? `0 0 0 6px ${energy.accent}55, 0 4px 12px rgba(0,0,0,.4)` : "0 4px 12px rgba(0,0,0,.4)",
                transform: active === i ? "scale(1.2)" : undefined,
              }}
            >
              {i + 1}
            </span>
            <span
              className={`pointer-events-none absolute left-9 whitespace-nowrap rounded-md bg-slate-900/90 px-2 py-1 text-xs font-medium text-white shadow-lg transition-opacity ${active === i ? "opacity-100" : "opacity-0 group-hover:opacity-100"}`}
            >
              {s.title}
            </span>
          </button>
        </Html>
      ))}
    </>
  );
}

export default function Viewer({ energy, clock, playing, speed, labels, focus, active, onSelect }: { energy: Energy; clock: Clock; playing: boolean; speed: number; labels: boolean; focus: Focus; active: number | null; onSelect: (i: number) => void }) {
  const SceneComp = SCENES[energy.id];
  return (
    <Canvas shadows dpr={[1, 1.75]} camera={{ position: [24, 14, 28], fov: 45, near: 0.1, far: 1500 }} gl={{ antialias: true }}>
      <fog attach="fog" args={["#c9d9e6", 110, 330]} />
      <Sky distance={450000} sunPosition={[10, 28, 18]} turbidity={5} rayleigh={1.4} mieCoefficient={0.004} mieDirectionalG={0.85} />
      <hemisphereLight args={["#cfe4ff", "#6b6a55", 0.55]} />
      <directionalLight
        position={[15, 42, 27]}
        intensity={2.8}
        color="#fff4e0"
        castShadow
        shadow-mapSize={[2048, 2048]}
        shadow-camera-left={-48}
        shadow-camera-right={48}
        shadow-camera-top={48}
        shadow-camera-bottom={-48}
        shadow-camera-near={1}
        shadow-camera-far={160}
        shadow-bias={-0.0004}
        shadow-normalBias={0.04}
      />
      <Environment resolution={256} environmentIntensity={0.7}>
        <Lightformer form="rect" intensity={2.2} position={[0, 20, 0]} rotation-x={Math.PI / 2} scale={[60, 60, 1]} color="#ffffff" />
        <Lightformer form="rect" intensity={1.2} position={[-25, 6, 10]} rotation-y={Math.PI / 2} scale={[30, 10, 1]} color="#dbeaff" />
        <Lightformer form="rect" intensity={1.2} position={[25, 6, -10]} rotation-y={-Math.PI / 2} scale={[30, 10, 1]} color="#fff0dc" />
        <Lightformer form="rect" intensity={0.8} position={[0, 6, -30]} scale={[60, 10, 1]} color="#ffffff" />
      </Environment>
      <Suspense fallback={null}>
        <SceneComp key={energy.id} clock={clock} />
      </Suspense>
      {labels && <Hotspots energy={energy} active={active} onSelect={onSelect} />}
      <OrbitControls makeDefault enableDamping dampingFactor={0.08} maxPolarAngle={Math.PI * 0.495} minDistance={2.5} maxDistance={110} />
      <CameraRig focus={focus} />
      <ClockDriver clock={clock} playing={playing} speed={speed} />
    </Canvas>
  );
}
