import type { V3 } from "./scenes/common";

export type Step = { title: string; text: string; pos: V3; cam: V3; target: V3 };
export type Use = { icon: string; title: string; text: string };
export type Energy = {
  id: "hydro" | "thermal" | "nuclear" | "solar" | "wind" | "pneumatic";
  group: string;
  name: string;
  short: string;
  emoji: string;
  accent: string;
  tagline: string;
  definition: string[];
  chain: { label: string; value: string }[];
  principle: string[];
  steps: Step[];
  uses: Use[];
  facts: { label: string; value: string }[];
  overview: { cam: V3; target: V3 };
};

export const ENERGIES: Energy[] = [
  /* ------------------------------------------------------------ */
  {
    id: "hydro",
    group: "Énergie électrique",
    name: "Centrale hydraulique",
    short: "Hydraulique",
    emoji: "💧",
    accent: "#38bdf8",
    tagline: "L'eau en hauteur devient électricité",
    definition: [
      "Une centrale hydraulique transforme l'énergie potentielle de l'eau stockée en hauteur (retenue d'un barrage) en énergie mécanique, puis en énergie électrique.",
      "C'est la première source d'électricité renouvelable au monde : elle ne consomme pas l'eau, elle l'utilise au passage et la restitue à la rivière.",
    ],
    chain: [
      { label: "Source", value: "Eau de la retenue" },
      { label: "Conversion 1", value: "Turbine (mécanique)" },
      { label: "Conversion 2", value: "Alternateur (électrique)" },
      { label: "Distribution", value: "Transformateur + ligne HT" },
    ],
    principle: [
      "L'eau de la retenue est captée à la prise d'eau et descend dans la conduite forcée : son énergie potentielle se transforme en énergie cinétique (vitesse) et en pression.",
      "Le jet d'eau fait tourner la turbine (Francis, Pelton ou Kaplan) à vitesse constante.",
      "La turbine entraîne l'alternateur : le rotor aimanté tourne dans le stator et produit un courant alternatif (principe de l'induction).",
      "Le transformateur élève la tension (jusqu'à 400 000 V) pour limiter les pertes sur la ligne haute tension.",
    ],
    steps: [
      { title: "Retenue d'eau", text: "Le lac stocke l'eau : plus la hauteur de chute est grande, plus l'énergie potentielle est importante (E = m·g·h).", pos: [-10, 5, 0], cam: [-8, 10, 20], target: [-9, 2, 0] },
      { title: "Barrage & prise d'eau", text: "Le barrage en béton retient l'eau. La prise d'eau, équipée d'une grille, envoie l'eau vers la conduite forcée.", pos: [-1.5, 5.2, -5], cam: [8, 9, 14], target: [-1, 2, -2] },
      { title: "Conduite forcée", text: "Tuyau en acier à forte pente : l'eau accélère et arrive sous pression sur la turbine.", pos: [-0.8, 2.2, 0], cam: [2, 4, 7], target: [0.5, 1.5, 0] },
      { title: "Turbine", text: "Les aubes de la turbine Francis sont poussées par l'eau : l'énergie hydraulique devient énergie mécanique de rotation.", pos: [6.4, 1.4, 0], cam: [10, 5.5, 8], target: [6.4, 1.4, 0] },
      { title: "Alternateur", text: "Relié à la turbine par l'arbre, l'alternateur convertit la rotation en courant électrique alternatif (50 Hz).", pos: [6.4, 3.2, 0], cam: [11, 6, 7], target: [6.4, 2.5, 0] },
      { title: "Transformateur & ligne HT", text: "Le transformateur élève la tension ; les pylônes transportent l'électricité vers les villes et les usines.", pos: [10, 2.9, 3.5], cam: [18, 7, 14], target: [13, 3, 3.5] },
    ],
    uses: [
      { icon: "🏙️", title: "Réseau électrique national", text: "Production de base et de pointe pour les villes et l'industrie." },
      { icon: "🔋", title: "Stockage d'énergie (STEP)", text: "Les stations de pompage-turbinage stockent l'énergie en remontant l'eau." },
      { icon: "🌾", title: "Irrigation & eau potable", text: "Les retenues servent aussi à l'agriculture, à la pêche et au tourisme." },
      { icon: "🌊", title: "Régulation des crues", text: "Les barrages protègent les vallées en cas de fortes pluies." },
    ],
    facts: [
      { label: "Rendement", value: "85 – 90 %" },
      { label: "Puissance", value: "jusqu'à 22 GW" },
      { label: "Durée de vie", value: "> 80 ans" },
      { label: "CO₂ émis", value: "≈ 6 g/kWh" },
    ],
    overview: { cam: [24, 14, 28], target: [3, 2, 0] },
  },
  /* ------------------------------------------------------------ */
  {
    id: "thermal",
    group: "Énergie électrique",
    name: "Centrale thermique",
    short: "Thermique",
    emoji: "🔥",
    accent: "#fb923c",
    tagline: "La chaleur du combustible fait tourner la turbine",
    definition: [
      "Une centrale thermique produit de l'électricité en brûlant un combustible (charbon, fioul, gaz) pour transformer l'eau en vapeur à haute pression.",
      "L'énergie chimique du combustible devient énergie thermique, puis mécanique, puis électrique.",
    ],
    chain: [
      { label: "Source", value: "Combustible (charbon, gaz)" },
      { label: "Conversion 1", value: "Chaudière (chaleur)" },
      { label: "Conversion 2", value: "Turbine + alternateur" },
      { label: "Distribution", value: "Transformateur + ligne HT" },
    ],
    principle: [
      "Le combustible est brûlé dans la chaudière : la chaleur transforme l'eau circulant dans les tubes en vapeur à plus de 500 °C.",
      "La vapeur sous haute pression se détend dans la turbine et la fait tourner à 3 000 tr/min.",
      "L'alternateur couplé à la turbine produit l'électricité.",
      "À la sortie, la vapeur est condensée en eau grâce au circuit de refroidissement (tour aéroréfrigérante), puis renvoyée à la chaudière : c'est un cycle fermé (cycle de Rankine).",
    ],
    steps: [
      { title: "Combustible", text: "Un convoyeur amène le charbon broyé (ou du gaz) jusqu'aux brûleurs de la chaudière.", pos: [-17, 4, 0], cam: [-22, 8, 14], target: [-15, 3, 0] },
      { title: "Chaudière", text: "La combustion chauffe les tubes d'eau : l'eau se vaporise. Les fumées sont évacuées par la cheminée.", pos: [-8, 11, 0], cam: [-2, 12, 18], target: [-8, 6, 0] },
      { title: "Turbine à vapeur", text: "La vapeur détendue fait tourner les roues à aubes : énergie thermique → énergie mécanique.", pos: [0.5, 4.2, 0], cam: [4, 6, 11], target: [1.5, 2.6, 0] },
      { title: "Alternateur", text: "L'alternateur transforme la rotation en électricité alternative.", pos: [4.6, 4.2, 0], cam: [10, 6, 10], target: [4.6, 2.6, 0] },
      { title: "Condenseur & tour de refroidissement", text: "La vapeur est refroidie, redevient liquide et retourne à la chaudière. La tour rejette de la vapeur d'eau.", pos: [14, 15, -8], cam: [26, 14, 8], target: [10, 6, -5] },
      { title: "Transformateur", text: "La tension est élevée avant l'envoi sur le réseau.", pos: [8, 2.9, 4], cam: [16, 7, 14], target: [10, 3, 5] },
    ],
    uses: [
      { icon: "🏭", title: "Production d'électricité", text: "Complément du réseau, démarrage rapide pour les pointes de consommation." },
      { icon: "♨️", title: "Cogénération", text: "La chaleur récupérée alimente des réseaux de chauffage urbain." },
      { icon: "🚢", title: "Propulsion navale", text: "Les navires à vapeur utilisent le même principe." },
      { icon: "🧪", title: "Industrie", text: "Vapeur pour la chimie, le papier, l'agroalimentaire." },
    ],
    facts: [
      { label: "Rendement", value: "35 – 60 %" },
      { label: "Température vapeur", value: "540 °C" },
      { label: "Vitesse turbine", value: "3 000 tr/min" },
      { label: "CO₂ émis", value: "400–1000 g/kWh" },
    ],
    overview: { cam: [18, 16, 34], target: [0, 6, 0] },
  },
  /* ------------------------------------------------------------ */
  {
    id: "nuclear",
    group: "Énergie électrique",
    name: "Centrale nucléaire",
    short: "Nucléaire",
    emoji: "⚛️",
    accent: "#22d3ee",
    tagline: "La fission de l'uranium chauffe l'eau",
    definition: [
      "Une centrale nucléaire produit de l'électricité à partir de la chaleur dégagée par la fission de noyaux d'uranium dans le cœur d'un réacteur.",
      "Contrairement à une centrale thermique classique, la chaleur provient du combustible nucléaire et non d'une combustion.",
    ],
    chain: [
      { label: "Source", value: "Uranium enrichi (fission)" },
      { label: "Conversion 1", value: "Réacteur + générateur de vapeur" },
      { label: "Conversion 2", value: "Turbine + alternateur" },
      { label: "Distribution", value: "Transformateur + ligne THT" },
    ],
    principle: [
      "Dans le cœur, la fission de l'uranium 235 libère une grande quantité de chaleur. Les barres de contrôle absorbent les neutrons et règlent la puissance.",
      "Circuit primaire : l'eau sous pression (155 bars) évacue la chaleur du cœur et la transporte au générateur de vapeur sans jamais bouillir.",
      "Circuit secondaire : l'eau du générateur de vapeur se vaporise et fait tourner la turbine reliée à l'alternateur.",
      "Circuit de refroidissement : le condenseur est refroidi par l'eau d'un fleuve ou de la mer, via des tours aéroréfrigérantes.",
    ],
    steps: [
      { title: "Réacteur (cœur)", text: "Le combustible en fission dégage la chaleur. Les barres de contrôle montent et descendent pour piloter la réaction.", pos: [-10.6, 4.2, 0], cam: [-7, 6, 9], target: [-10.6, 2, 0] },
      { title: "Circuit primaire & générateur de vapeur", text: "L'eau radioactive du circuit primaire chauffe l'eau du circuit secondaire sans jamais la mélanger.", pos: [-6.6, 5.1, 0], cam: [-1, 7, 10], target: [-7, 2.5, 0] },
      { title: "Turbine à vapeur", text: "La vapeur du circuit secondaire entraîne la turbine à 1 500 ou 3 000 tr/min.", pos: [4.1, 3.9, 0], cam: [8, 6, 11], target: [4.5, 2.4, 0] },
      { title: "Alternateur", text: "Il convertit la rotation en électricité alternative.", pos: [7.6, 3.9, 0], cam: [13, 6, 10], target: [7.6, 2.4, 0] },
      { title: "Condenseur & tours de refroidissement", text: "Le panache blanc est de la simple vapeur d'eau : la chaleur résiduelle est évacuée dans l'atmosphère.", pos: [17, 16, -8], cam: [30, 16, 8], target: [14, 7, -10] },
      { title: "Transformateur & ligne THT", text: "L'électricité est envoyée sur le réseau à très haute tension.", pos: [8, 2.9, 5.5], cam: [16, 8, 17], target: [10, 3, 7] },
    ],
    uses: [
      { icon: "⚡", title: "Électricité de base", text: "Production continue, très puissante et pilotable." },
      { icon: "🚢", title: "Propulsion", text: "Sous-marins, porte-avions et brise-glaces nucléaires." },
      { icon: "🩺", title: "Médecine", text: "Production de radio-isotopes pour l'imagerie et la radiothérapie." },
      { icon: "🛰️", title: "Espace", text: "Générateurs pour sondes spatiales lointaines." },
    ],
    facts: [
      { label: "Rendement", value: "≈ 33 %" },
      { label: "Puissance / réacteur", value: "900 – 1 650 MW" },
      { label: "Pression primaire", value: "155 bars" },
      { label: "CO₂ émis", value: "≈ 12 g/kWh" },
    ],
    overview: { cam: [10, 17, 34], target: [4, 4, -3] },
  },
  /* ------------------------------------------------------------ */
  {
    id: "solar",
    group: "Énergie solaire",
    name: "Panneaux photovoltaïques",
    short: "Solaire",
    emoji: "☀️",
    accent: "#facc15",
    tagline: "La lumière du soleil devient électricité",
    definition: [
      "L'énergie solaire photovoltaïque convertit directement le rayonnement du Soleil en électricité grâce à des cellules en silicium, sans pièce en mouvement.",
      "Le Soleil envoie sur Terre plus d'énergie en une heure que l'humanité n'en consomme en un an.",
    ],
    chain: [
      { label: "Source", value: "Rayonnement solaire" },
      { label: "Conversion 1", value: "Cellules PV (courant continu)" },
      { label: "Conversion 2", value: "Onduleur (continu → alternatif)" },
      { label: "Utilisation", value: "Habitation / réseau / batterie" },
    ],
    principle: [
      "Les photons de la lumière frappent les cellules en silicium et arrachent des électrons : c'est l'effet photovoltaïque.",
      "Un champ électrique interne (jonction P-N) met ces électrons en mouvement : un courant continu (DC) apparaît.",
      "Les panneaux sont reliés en série et en parallèle pour obtenir la tension et la puissance voulues.",
      "L'onduleur transforme le courant continu en courant alternatif utilisable par la maison. Le surplus est stocké en batterie ou injecté dans le réseau.",
    ],
    steps: [
      { title: "Rayonnement solaire", text: "Le Soleil envoie des photons ; la production dépend de l'ensoleillement et de l'inclinaison des panneaux.", pos: [10, 16, 12], cam: [20, 12, 26], target: [2, 4, 0] },
      { title: "Panneaux photovoltaïques", text: "Chaque panneau regroupe des dizaines de cellules en silicium protégées par une vitre.", pos: [0, 2.3, 0], cam: [6, 4, 9], target: [0, 1, 0] },
      { title: "Câblage en courant continu", text: "Les rangées de panneaux sont reliées en courant continu jusqu'à l'onduleur.", pos: [-7.6, 0.8, 0], cam: [-3, 4, 9], target: [-8, 0.5, 0] },
      { title: "Onduleur", text: "Il convertit le courant continu (DC) en courant alternatif (AC) à 230 V / 50 Hz.", pos: [-9.9, 2.1, 0], cam: [-4, 4, 8], target: [-10, 1, 0] },
      { title: "Batterie de stockage", text: "L'énergie excédentaire est stockée pour être utilisée la nuit.", pos: [-9.9, 1.5, 3.4], cam: [-3, 4, 10], target: [-10, 0.8, 3.4] },
      { title: "Habitation", text: "Le courant alternatif alimente l'éclairage, les appareils et le chauffage de la maison.", pos: [-16, 5.2, 0], cam: [-6, 7, 14], target: [-15, 2, 0] },
    ],
    uses: [
      { icon: "🏠", title: "Toitures & maisons", text: "Autoconsommation et réduction de la facture d'électricité." },
      { icon: "🌍", title: "Sites isolés", text: "Villages, pompes à eau, éclairage public hors réseau." },
      { icon: "🛰️", title: "Satellites", text: "Les ailes solaires alimentent les satellites et la station spatiale." },
      { icon: "🏞️", title: "Centrales solaires", text: "Des centaines d'hectares de panneaux injectent sur le réseau." },
    ],
    facts: [
      { label: "Rendement cellule", value: "18 – 24 %" },
      { label: "Durée de vie", value: "25 – 30 ans" },
      { label: "Puissance panneau", value: "400 – 600 Wc" },
      { label: "CO₂ émis", value: "≈ 30 g/kWh" },
    ],
    overview: { cam: [6, 10, 26], target: [-4, 1, 0] },
  },
  /* ------------------------------------------------------------ */
  {
    id: "wind",
    group: "Énergie éolienne",
    name: "Éolienne",
    short: "Éolienne",
    emoji: "🌬️",
    accent: "#4ade80",
    tagline: "La force du vent fait tourner le rotor",
    definition: [
      "Une éolienne transforme l'énergie cinétique du vent en énergie mécanique de rotation, puis en énergie électrique grâce à un générateur.",
      "Regroupées, les éoliennes forment un parc éolien terrestre ou en mer.",
    ],
    chain: [
      { label: "Source", value: "Vent (énergie cinétique)" },
      { label: "Conversion 1", value: "Rotor + multiplicateur" },
      { label: "Conversion 2", value: "Générateur (électrique)" },
      { label: "Distribution", value: "Transformateur + réseau" },
    ],
    principle: [
      "Le vent exerce une portance sur les pales profilées comme des ailes d'avion : le rotor tourne lentement (10 à 20 tr/min).",
      "Le multiplicateur augmente la vitesse (jusqu'à 1 500 tr/min) pour le générateur.",
      "Le générateur produit de l'électricité ; plus le vent est fort, plus la puissance est élevée (elle varie avec le cube de la vitesse du vent : P = ½·ρ·S·v³·Cp).",
      "La nacelle s'oriente face au vent, et les pales peuvent pivoter (calage) pour réguler la puissance ou s'arrêter en cas de tempête.",
    ],
    steps: [
      { title: "Le vent", text: "Source d'énergie gratuite et renouvelable. Les éoliennes sont placées en hauteur, là où le vent est fort et régulier.", pos: [16, 17, 5], cam: [26, 16, 22], target: [0, 12, 0] },
      { title: "Rotor : pales & moyeu", text: "Les trois pales profilées captent le vent et entraînent le moyeu en rotation.", pos: [2.6, 17.5, 0], cam: [12, 15, 10], target: [2, 14.3, 0] },
      { title: "Nacelle : multiplicateur & générateur", text: "À l'intérieur de la nacelle, le multiplicateur accélère la rotation et le générateur produit le courant.", pos: [-0.5, 16, 0], cam: [-8, 17, 9], target: [0, 14.3, 0] },
      { title: "Mât", text: "Le mât (80 à 120 m) porte la nacelle et abrite les câbles et l'ascenseur de maintenance.", pos: [0.6, 7, 0.5], cam: [9, 7, 9], target: [0, 7, 0] },
      { title: "Transformateur", text: "Il élève la tension du courant produit avant l'injection dans le réseau.", pos: [7, 2.9, 5.5], cam: [14, 6, 14], target: [5, 1.5, 3] },
      { title: "Réseau électrique", text: "Les lignes aériennes transportent l'électricité vers les consommateurs.", pos: [15, 10.5, 5.5], cam: [24, 10, 18], target: [18, 4, 5.5] },
    ],
    uses: [
      { icon: "🏞️", title: "Parcs éoliens terrestres", text: "Production d'électricité renouvelable injectée sur le réseau." },
      { icon: "🌊", title: "Éolien en mer (offshore)", text: "Vents plus forts et réguliers, éoliennes géantes de 10 à 15 MW." },
      { icon: "🚜", title: "Pompage & sites isolés", text: "Petites éoliennes pour pomper l'eau ou alimenter des fermes." },
      { icon: "⛵", title: "Bateaux & recharge", text: "Mini-éoliennes pour recharger des batteries." },
    ],
    facts: [
      { label: "Rendement max (Betz)", value: "59 %" },
      { label: "Diamètre rotor", value: "80 – 220 m" },
      { label: "Puissance", value: "2 – 15 MW" },
      { label: "CO₂ émis", value: "≈ 12 g/kWh" },
    ],
    overview: { cam: [22, 17, 26], target: [0, 9, 0] },
  },
  /* ------------------------------------------------------------ */
  {
    id: "pneumatic",
    group: "Énergie pneumatique",
    name: "Énergie pneumatique",
    short: "Pneumatique",
    emoji: "💨",
    accent: "#a78bfa",
    tagline: "L'air comprimé qui pousse, serre et soulève",
    definition: [
      "L'énergie pneumatique utilise la pression de l'air comprimé pour produire un mouvement et une force : c'est l'énergie des vérins, des outils à air et des automatismes industriels.",
      "Elle appartient à la fonction « Alimenter » de la chaîne d'énergie : elle fournit l'énergie à l'actionneur, qui la convertit en travail mécanique.",
    ],
    chain: [
      { label: "Alimenter", value: "Compresseur + réservoir" },
      { label: "Distribuer", value: "Distributeur 5/2" },
      { label: "Convertir", value: "Vérin (actionneur)" },
      { label: "Transmettre", value: "Tige + pousseur → charge" },
    ],
    principle: [
      "Le compresseur aspire l'air ambiant et le comprime à 6–10 bars ; le réservoir stocke et stabilise la pression.",
      "L'unité FRL filtre, régule la pression et lubrifie l'air avant son arrivée sur les composants.",
      "Le distributeur 5/2, commandé par électro-aimant, envoie l'air tantôt dans la chambre arrière (la tige sort), tantôt dans la chambre avant (la tige rentre).",
      "Le vérin double effet convertit la pression en force : F = P × S. Ici, il pousse des caisses sur un convoyeur.",
    ],
    steps: [
      { title: "Compresseur", text: "Le moteur électrique entraîne la pompe à piston : l'air est aspiré puis comprimé.", pos: [-6, 3.5, 0], cam: [-10, 5, 8], target: [-6, 2, 0] },
      { title: "Réservoir d'air", text: "Il stocke l'air comprimé. Le manomètre indique la pression disponible.", pos: [-7.7, 2.3, 0.8], cam: [-9, 3, 7], target: [-6.5, 1.4, 0] },
      { title: "Unité FRL", text: "Filtre – Régulateur – Lubrificateur : prépare l'air (propre, à pression constante, légèrement huilé).", pos: [-2.4, 3.3, 0], cam: [-1, 4.5, 6], target: [-2.4, 2.2, 0] },
      { title: "Distributeur 5/2", text: "Pilotés par les électro-aimants (voyants verts/orange), il aiguille l'air vers la bonne chambre du vérin.", pos: [1.4, 2.6, 0], cam: [2, 4, 6], target: [1.4, 1.8, 0] },
      { title: "Vérin double effet", text: "Chambre bleue sous pression : la tige sort. Chambre orange sous pression : la tige rentre.", pos: [5.2, 2.7, 0], cam: [6, 4.5, 8], target: [5.2, 1.6, 0] },
      { title: "Pousseur & charge", text: "La tige pousse la caisse sur le convoyeur : l'énergie pneumatique est devenue travail mécanique.", pos: [9, 2.3, 0], cam: [11, 5, 8], target: [9, 1.4, 0] },
    ],
    uses: [
      { icon: "🏭", title: "Automatisation industrielle", text: "Vérins de poussée, de serrage, de tri et de palettisation." },
      { icon: "🔧", title: "Outils à air comprimé", text: "Clés à choc, perceuses, marteaux-piqueurs, pistolets de peinture." },
      { icon: "🚌", title: "Transport", text: "Freinage pneumatique des camions, bus et trains, ouverture des portes." },
      { icon: "🦷", title: "Médical & alimentaire", text: "Fraises dentaires, emballage, systèmes propres sans huile." },
    ],
    facts: [
      { label: "Pression de service", value: "6 – 10 bars" },
      { label: "Vitesse vérin", value: "0,1 – 1,5 m/s" },
      { label: "Rendement global", value: "10 – 20 %" },
      { label: "Atout", value: "Propre, rapide, sûr" },
    ],
    overview: { cam: [4, 7, 17], target: [3, 1.4, 0] },
  },
];
